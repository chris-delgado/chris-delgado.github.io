---
Ingredients:
- 70g unpopped kernels
- 1 tsp olive oil
Steps:
- 1. Add ingredients to popcorn maker then turn on
- 2. Turn off when time between pops becomes greater than 3 seconds
---
**Index**::  [[Meal Prep]]

# Popcorn

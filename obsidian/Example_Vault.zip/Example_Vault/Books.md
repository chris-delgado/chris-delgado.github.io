[[Resources]]

# Books
[[20221107 Building a Second Brain]]
[[20221028 The Obstacle Is the Way]]
[[20220911 The Sirens of Titan]]
[[20220510 Digital Gold]]
[[20220409 Grit]]
[[20211031 On Writing]]
[[20210716 Range]]
[[20210515 Atomic Habits]]
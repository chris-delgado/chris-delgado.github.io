---
Ingredients: 
- 120mL almond milk
- 30g chia seeds
- 20g chocolate whey protein
Steps: 
- 1. Combine ingredients and shake well
- 2. Refrigerate overnight
- 3. Add toppings (e.g. bananas, walnuts, pepitas)
---
**Index**:: [[Meal Prep]]

# Chia Pudding
## Ingredients
- 30g chia seeds
- 120mL almond milk
- 20g chocolate whey protein

## Steps
1. Combine ingredients and shake well
2. Refrigerate overnight
3. Add toppings (e.g. bananas, walnuts, pepitas)
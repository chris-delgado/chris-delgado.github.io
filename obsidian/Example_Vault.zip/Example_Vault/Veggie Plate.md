---
Ingredients:
- 100g baby carrots
- 100g greens (peas/green beans/broccoli)
- 1 whole potato
- 125g protein (chicken/turkey/fish)
Steps:
- 1. Put on a plate and microwave
---
**Index**:: [[Meal Prep]]

# Veggie Plate

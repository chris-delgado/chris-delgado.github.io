---
Ingredients:
- asparagus (20m)
- broccoli (15m)
- carrots (25m)
- cauliflower (25m)
- green beans (15m)
- 3 cups water
Steps:
- 1. Fill steamer with 3 cups water
- 2. Fill basket with 1 type of veggie
- 3. Set to smart steam for specified time
- 4. Remove immediatly to prevent overcooking
---
**Index**:: [[Meal Prep]]

# Steamed Veggies

---
Goal: 
Outcome: 
Deadline: 
Status: In Progress
---
**Index**:: [[Projects]]
**Areas**:: 
**Deliverable**:: 
**Start**:: [[<%tp.date.now()%>]]
**End**:: 

# <%tp.file.title%>
## Milestones

## Next Steps

## Resources

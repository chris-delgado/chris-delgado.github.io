const tokenNames = [
  "icon-token_1_sealed",
  "icon-token_0_sealed",
  "icon-token_-1_sealed",
  "icon-token_-2_sealed",
  "icon-token_-3_sealed",
  "icon-token_-4_sealed",
  "icon-token_-5_sealed",
  "icon-token_-6_sealed",
  "icon-token_-7_sealed",
  "icon-token_-8_sealed",
  "icon-token_skull_highlight",
  "icon-token_cultist_highlight",
  "icon-token_tablet_highlight",
  "icon-token_elder_thing_highlight",
  "icon-token_auto_fail_highlight",
  "icon-token_elder_sign_highlight",
  "icon-token_frost_sealed",
  "icon-token_bless_sealed",
  "icon-token_curse_sealed"
];

const presets = {
  'The Night of the Zealot': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 1, 1, 0, 1, 1, 0, 0, 0]
  },
  'The Dunwich Legacy': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 1, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Path to Carcosa': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 3, 0, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Forgotten Age': {
    easy: [2, 3, 2, 1, 1, 0, 0, 0, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    standard: [1, 3, 1, 2, 1, 0, 1, 0, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    hard: [1, 2, 1, 1, 2, 1, 0, 1, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    expert: [0, 1, 1, 2, 2, 2, 0, 1, 0, 1, 2, 0, 0, 1, 1, 1, 0, 0, 0]
  },
  'The Circle Undone': {
    easy: [2, 3, 2, 1, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 2, 2, 1, 1, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 2, 2, 2, 1, 1, 1, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 1, 1, 0, 1, 0, 1, 2, 0, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Dream-Eaters': {
    easy: [2, 3, 2, 2, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    hard: [0, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 1, 2, 1, 1, 0, 1, 0, 1, 2, 0, 1, 1, 0, 0, 0]
  },
  'The Innsmouth Conspiracy': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2, 1, 1, 0, 0, 0]
  },
  'Edge of the Earth': {
    easy: [3, 2, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 1, 0, 0],
    hard: [0, 2, 2, 2, 1, 2, 1, 0, 0, 0, 2, 1, 1, 0, 1, 1, 2, 0, 0],
    expert: [0, 1, 1, 2, 1, 2, 1, 0, 1, 0, 2, 1, 1, 0, 1, 1, 3, 0, 0]
  },
  'The Scarlet Keys': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 0, 1, 1, 1, 1, 0, 0, 0]
  },
};

// HTML Elements
const htmlElements = {
  contentContainer: document.getElementById('drawn-token-value'),
  tokenImage: document.getElementById('token-image'),
  difficultySelector: document.getElementById('difficulty'),
  campaignSelector: document.getElementById('campaign'),
  drawTokenButton: document.getElementById('draw-token-button'),
  addTokenButton: document.getElementById('add-token-button'),
  removeTokenButton: document.getElementById('remove-token-button'),
  tokenInput: document.getElementById('token-input'),
  modifyBagButton: document.getElementById('modify-bag-button'),
  overlay: document.getElementById('overlay'),
  closeOverlayButton: document.getElementById('close-overlay'),
  bagContents: document.getElementById('bag-contents'),
  displayOddsCheckbox: document.getElementById('display-odds'),
  revealAnotherButton: document.getElementById('reveal-another-button'),
  historyButton: document.getElementById('history-button'),
  instructionsElement: document.getElementById('instructions'),
  subtitle: document.getElementById('subtitle'),
  closeHistoryOverlayButton: document.getElementById('close-history-overlay'),
  historyOverlay: document.getElementById('history-overlay'),
  drawHistory: document.getElementById('draw-history'),
  drawHistoryTotal: document.getElementById('draw-history-total')
};

// Variables
let drawHistory = [];
let drawnTokens = [];
let tokenValues = [];
let selectedCampaign = 'The Night of the Zealot';
let selectedDifficulty = 'easy';
let chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
let chaosBagCopy = [...chaosBag];

// Functions
const calculateOdds = tokenValue => {
  let totalTokens = chaosBagCopy.reduce((sum, quantity) => sum + quantity, 0);
  let tokenCount = chaosBagCopy[tokenValue];
  let odds = (tokenCount / totalTokens) * 100;
  odds = Math.round(odds * 10) / 10;
  return odds + '%';
};

const showOdds = () => {
  htmlElements.contentContainer.style.display = 'block';
};

const hideOdds = () => {
  htmlElements.contentContainer.style.display = 'none';
};

const resetChaosBag = () => {
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  drawnTokens = [];
};

const showContents = () => {
  htmlElements.tokenImage.className = '';
  let tokenValues = [];
  chaosBagCopy = [...chaosBag];

  chaosBag.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  htmlElements.contentContainer.innerHTML = '';
  htmlElements.bagContents.innerHTML = '';

  let row = document.createElement('div');
  row.className = 'row';
  htmlElements.bagContents.appendChild(row);

  tokenValues.forEach(function(value) {
    let token = document.createElement('span');
    token.className = tokenNames[value];
    row.appendChild(token);
  });

  if (htmlElements.displayOddsCheckbox.checked) {
    showOdds();
  } else {
    hideOdds();
  }
  updateBagTotal();
};

const updateSubtitle = () => {
  htmlElements.subtitle.textContent = `${selectedCampaign} | ${selectedDifficulty}`;
};

const updateBagTotal = () => {
  const bagTotalElement = document.getElementById('bag-total');
  const totalTokens = chaosBag.reduce((sum, quantity) => sum + quantity, 0);
  bagTotalElement.textContent = `${totalTokens}`;
};

// Event Listener Functions
const drawToken = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  tokenValues = [];
  chaosBagCopy = [...chaosBag];

  chaosBag.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  let randomIndex = Math.floor(Math.random() * tokenValues.length);
  let randomValue = tokenValues[randomIndex];
  let className = tokenNames[randomValue];
  let odds = calculateOdds(randomValue);

  // Add drawn token to history
  drawHistory.push(tokenNames[randomValue]);
  
  // Decrement the quantity of the selected token
  chaosBagCopy[randomValue]--;

  if (className === "icon-token_bless_sealed" || className === "icon-token_curse_sealed") {
    tokenValues.splice(randomIndex, 1); // Remove the value from the tokenValues array
    chaosBag[randomValue]--; // Decrement the quantity in the chaosBag array
  }

  // Disable the "Draw Token" button
  htmlElements.drawTokenButton.disabled = true;

  // Add a visual indicator
  htmlElements.drawTokenButton.innerText = "Drawing...";

  // Enable the "Reveal Another" button
  htmlElements.revealAnotherButton.disabled = false;

  // Disable the instructions
  htmlElements.instructionsElement.style.display = 'none';

  // Reset the visual indicator after a short delay
  setTimeout(() => {
    if (htmlElements.displayOddsCheckbox.checked) {
      htmlElements.contentContainer.textContent = `Odds: ${odds}`;
    } else {
      htmlElements.contentContainer.textContent = '';
    }
    htmlElements.tokenImage.className = className;
    htmlElements.drawTokenButton.disabled = false;
    htmlElements.drawTokenButton.innerText = "Draw Token";

    // Calculate the number of available tokens remaining
    let availableTokens = tokenValues.filter(value => !drawnTokens.includes(value));
    htmlElements.revealAnotherButton.innerText = `Reveal Another (${availableTokens.length - 1})`;
  }, 500);
};


const revealAnotherToken = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';

  // Calculate tokenValues
  tokenValues = [];
  chaosBagCopy.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  // Exclude drawn tokens from the pool
  let availableTokens = tokenValues.filter(value => !drawnTokens.includes(value));

  if (availableTokens.length === 0) {
    alert('No more tokens left!');
    return;
  }

  // Count the quantity of each available token
  let tokenCounts = {};
  availableTokens.forEach(token => {
    tokenCounts[token] = (tokenCounts[token] || 0) + 1;
  });

  // Create an array of available tokens with their quantities
  let tokensWithQuantities = Object.entries(tokenCounts);

  // Generate a random index based on the available tokens
  let randomIndex = Math.floor(Math.random() * tokensWithQuantities.length);
  let [randomValue] = tokensWithQuantities[randomIndex];
  let className = tokenNames[randomValue];
  let odds = calculateOdds(randomValue);

  // Add drawn token to history
  drawHistory.push(tokenNames[randomValue]);

  // Decrement the quantity of the selected token
  chaosBagCopy[randomValue]--;

  // Remove the token from the availableTokens if its quantity reaches zero
  if (chaosBagCopy[randomValue] === 0) {
    availableTokens = availableTokens.filter(token => token !== randomValue);
  }

  // Add the drawn token to drawnTokens
  drawnTokens.push(randomValue);

  // Disable the "Reveal Another" button
  htmlElements.revealAnotherButton.disabled = true;

  // Add a visual indicator
  htmlElements.revealAnotherButton.innerText = "Revealing...";

  // Reset the visual indicator after a short delay
  setTimeout(() => {
    let tokenImg = document.createElement('img');
    tokenImg.className = className;
    htmlElements.tokenImage.className = className;

    if (className === "icon-token_bless_sealed" || className === "icon-token_curse_sealed") {
      tokenValues.splice(randomIndex, 1); // Remove the value from the tokenValues array
      chaosBag[randomValue]--; // Decrement the quantity in the chaosBag array
    }

    if (htmlElements.displayOddsCheckbox.checked) {
      htmlElements.contentContainer.textContent = `Odds: ${odds}`;
    } else {
      htmlElements.contentContainer.textContent = '';
    }

    // Update the "Reveal Another" button text
    htmlElements.revealAnotherButton.innerText = `Reveal Another (${availableTokens.length - 1})`;

    // Enable the "Reveal Another" button
    htmlElements.revealAnotherButton.disabled = false;
  }, 500);
};

const modifyBag = () => {
  htmlElements.overlay.classList.toggle('overlay-visible');
  htmlElements.revealAnotherButton.disabled = true;
  htmlElements.revealAnotherButton.innerText = 'Reveal Another';
  showContents();
  htmlElements.instructionsElement.style.display = 'block';
};

const addToken = () => {
  let tokenName = "icon-token_" + htmlElements.tokenInput.value + (
    htmlElements.tokenInput.value === 'cultist' || 
    htmlElements.tokenInput.value === 'tablet' || 
    htmlElements.tokenInput.value === 'skull' ||
    htmlElements.tokenInput.value === 'elder_thing' ||
    htmlElements.tokenInput.value === 'elder_sign' ||
    htmlElements.tokenInput.value === 'auto_fail' ? '_highlight' : '_sealed');
  if (tokenNames.includes(tokenName)) {
    let tokenIndex = tokenNames.indexOf(tokenName);
    if (tokenIndex !== -1) {
      chaosBag[tokenIndex] += 1;
    } else {
      alert('Invalid token name. Please select a valid token from the dropdown.');
    }
    showContents();
  } else {
    alert('Invalid token name. Please select a valid token from the dropdown.');
  }
};

const removeToken = () => {
  let tokenName = "icon-token_" + htmlElements.tokenInput.value + (
    htmlElements.tokenInput.value === 'cultist' || 
    htmlElements.tokenInput.value === 'tablet' || 
    htmlElements.tokenInput.value === 'skull' ||
    htmlElements.tokenInput.value === 'elder_thing' ||
    htmlElements.tokenInput.value === 'elder_sign' ||
    htmlElements.tokenInput.value === 'auto_fail' ? '_highlight' : '_sealed');
  if (tokenNames.includes(tokenName)) {
    let tokenIndex = tokenNames.indexOf(tokenName);
    if (tokenIndex !== -1) {
      chaosBag[tokenIndex] = Math.max(0, chaosBag[tokenIndex] - 1);
    } else {
      alert('Invalid token name. Please select a valid token from the dropdown.');
    }
    showContents();
  } else {
    alert('Invalid token name. Please select a valid token from the dropdown.');
  }
};

const closeOverlay = () => {
  htmlElements.overlay.classList.remove('overlay-visible');
};

const toggleDisplayOdds = () => {
  if (htmlElements.displayOddsCheckbox.checked) {
    showOdds();
  } else {
    hideOdds();
  }
};

const changeCampaign = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  selectedCampaign = htmlElements.campaignSelector.value;
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  showContents();
  updateSubtitle(); // Update the subtitle when the campaign changes
};

const changeDifficulty = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  selectedDifficulty = htmlElements.difficultySelector.value;
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  showContents();
  updateSubtitle(); // Update the subtitle when the difficulty changes
};

const displayHistory = () => {
  // clear any existing history
  htmlElements.drawHistory.innerHTML = '';

  // Add the token images to the history overlay
  drawHistory.forEach(tokenName => {
    let tokenSpan = document.createElement('span');
    tokenSpan.className = tokenName;
    htmlElements.drawHistory.appendChild(tokenSpan);
  });

  // Update the total
  htmlElements.drawHistoryTotal.textContent = `${drawHistory.length}`;

  // Show the history overlay
  htmlElements.historyOverlay.classList.add('overlay-visible');
};

const closeHistoryOverlay = () => {
  htmlElements.historyOverlay.classList.remove('overlay-visible');
};

// Event Listeners
htmlElements.drawTokenButton.addEventListener('click', drawToken);
htmlElements.revealAnotherButton.addEventListener('click', revealAnotherToken);
htmlElements.modifyBagButton.addEventListener('click', modifyBag);
htmlElements.addTokenButton.addEventListener('click', addToken);
htmlElements.removeTokenButton.addEventListener('click', removeToken);
htmlElements.closeOverlayButton.addEventListener('click', closeOverlay);
htmlElements.displayOddsCheckbox.addEventListener('change', toggleDisplayOdds);
htmlElements.campaignSelector.addEventListener('change', changeCampaign);
htmlElements.difficultySelector.addEventListener('change', changeDifficulty);
htmlElements.historyButton.addEventListener('click', displayHistory);
htmlElements.closeHistoryOverlayButton.addEventListener('click', closeHistoryOverlay);

// Initial setup
htmlElements.revealAnotherButton.disabled = true;
hideOdds();
updateSubtitle();
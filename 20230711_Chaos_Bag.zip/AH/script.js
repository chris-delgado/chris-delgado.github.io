// TODO: Append Reveal Another token
// TODO: Fix modify bag display bug
// IDEA: Use enums instead of quantities for token presets?
// IDEA: Change the background depending on the campaign that is selected
// IDEA: Make autofail red and elder sign blue; skull a deeper red
const tokenNames = [
  "icon-token_1_sealed",
  "icon-token_0_sealed",
  "icon-token_-1_sealed",
  "icon-token_-2_sealed",
  "icon-token_-3_sealed",
  "icon-token_-4_sealed",
  "icon-token_-5_sealed",
  "icon-token_-6_sealed",
  "icon-token_-7_sealed",
  "icon-token_-8_sealed",
  "icon-token_skull_sealed",
  "icon-token_cultist_sealed",
  "icon-token_tablet_sealed",
  "icon-token_elder_thing_sealed",
  "icon-token_auto_fail_sealed",
  "icon-token_elder_sign_sealed",
  "icon-token_frost_sealed",
  "icon-token_bless_sealed",
  "icon-token_curse_sealed"
];

const presets = {
  'The Night of the Zealot': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 1, 1, 0, 1, 1, 0, 0, 0]
  },
  'The Dunwich Legacy': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 1, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Path to Carcosa': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 3, 0, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Forgotten Age': {
    easy: [2, 3, 2, 1, 1, 0, 0, 0, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    standard: [1, 3, 1, 2, 1, 0, 1, 0, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    hard: [1, 2, 1, 1, 2, 1, 0, 1, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    expert: [0, 1, 1, 2, 2, 2, 0, 1, 0, 1, 2, 0, 0, 1, 1, 1, 0, 0, 0]
  },
  'The Circle Undone': {
    easy: [2, 3, 2, 1, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 2, 2, 1, 1, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 2, 2, 2, 1, 1, 1, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 1, 1, 0, 1, 0, 1, 2, 0, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Dream-Eaters': {
    easy: [2, 3, 2, 2, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    hard: [0, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 1, 2, 1, 1, 0, 1, 0, 1, 2, 0, 1, 1, 0, 0, 0]
  },
  'The Innsmouth Conspiracy': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2, 1, 1, 0, 0, 0]
  },
  'Edge of the Earth': {
    easy: [3, 2, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 1, 0, 0],
    hard: [0, 2, 2, 2, 1, 2, 1, 0, 0, 0, 2, 1, 1, 0, 1, 1, 2, 0, 0],
    expert: [0, 1, 1, 2, 1, 2, 1, 0, 1, 0, 2, 1, 1, 0, 1, 1, 3, 0, 0]
  },
  'The Scarlet Keys': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 0, 1, 1, 1, 1, 0, 0, 0]
  },
};

// HTML Elements
const htmlElements = {
  contentContainer: document.getElementById('drawn-token-value'),
  tokenImage: document.getElementById('token-image'),
  difficultySelector: document.getElementById('difficulty'),
  campaignSelector: document.getElementById('campaign'),
  drawTokenButton: document.getElementById('draw-token-button'),
  addTokenButton: document.getElementById('add-token-button'),
  removeTokenButton: document.getElementById('remove-token-button'),
  tokenInput: document.getElementById('token-input'),
  modifyBagButton: document.getElementById('modify-bag-button'),
  overlay: document.getElementById('overlay'),
  closeOverlayButton: document.getElementById('close-overlay'),
  bagContents: document.getElementById('bag-contents'),
  displayOddsCheckbox: document.getElementById('display-odds'),
  revealAnotherButton: document.getElementById('reveal-another-button')
};

// Variables
let drawnTokens = [];
let tokenValues = [];
let selectedCampaign = 'The Night of the Zealot';
let selectedDifficulty = 'easy';
let chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
let chaosBagCopy = [...chaosBag];

// Functions
const calculateOdds = tokenValue => {
  let totalTokens = chaosBagCopy.reduce((sum, quantity) => sum + quantity, 0);
  let tokenCount = chaosBagCopy[tokenValue];
  let odds = (tokenCount / totalTokens) * 100;
  odds = Math.round(odds * 10) / 10;
  return odds + '%';
};

const showOdds = () => {
  htmlElements.contentContainer.style.display = 'block';
};

const hideOdds = () => {
  htmlElements.contentContainer.style.display = 'none';
};

const resetChaosBag = () => {
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  drawnTokens = [];
};

const showContents = () => {
  htmlElements.tokenImage.className = '';
  let tokenValues = [];
  chaosBagCopy = [...chaosBag];

  chaosBag.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  htmlElements.contentContainer.innerHTML = '';
  htmlElements.bagContents.innerHTML = '';

  let row = document.createElement('div');
  row.className = 'row';
  htmlElements.bagContents.appendChild(row);

  tokenValues.forEach(function(value) {
    let token = document.createElement('span');
    token.className = tokenNames[value];
    row.appendChild(token);
  });

  if (htmlElements.displayOddsCheckbox.checked) {
    showOdds();
  } else {
    hideOdds();
  }
};

// Event Listener Functions
const drawToken = () => {
  tokenValues = [];
  chaosBagCopy = [...chaosBag];

  chaosBag.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  let randomIndex = Math.floor(Math.random() * tokenValues.length);
  let randomValue = tokenValues[randomIndex];
  let className = tokenNames[randomValue];
  let odds = calculateOdds(randomValue);

  // Decrement the quantity of the selected token
  chaosBagCopy[randomValue]--;

  if (className === "icon-token_bless_sealed" || className === "icon-token_curse_sealed") {
    tokenValues.splice(randomIndex, 1); // Remove the value from the tokenValues array
    chaosBag[randomValue]--; // Decrement the quantity in the chaosBag array
  }

  if (htmlElements.displayOddsCheckbox.checked) {
    htmlElements.contentContainer.textContent = `Odds: ${odds}`;
  } else {
    htmlElements.contentContainer.textContent = '';
  }
  htmlElements.tokenImage.className = className;

  // Enable the "Reveal Another" button
  htmlElements.revealAnotherButton.disabled = false;
};

const revealAnotherToken = () => {
  // Calculate tokenValues
  tokenValues = [];
  chaosBagCopy.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  // Exclude drawn tokens from the pool
  let availableTokens = tokenValues.filter(value => !drawnTokens.includes(value));

  if (availableTokens.length === 0) {
    alert('No more tokens left!');
    return;
  }

  // Count the quantity of each available token
  let tokenCounts = {};
  availableTokens.forEach(token => {
    tokenCounts[token] = (tokenCounts[token] || 0) + 1;
  });

  // Create an array of available tokens with their quantities
  let tokensWithQuantities = Object.entries(tokenCounts);

  // Generate a random index based on the available tokens
  let randomIndex = Math.floor(Math.random() * tokensWithQuantities.length);
  let [randomValue] = tokensWithQuantities[randomIndex];
  let className = tokenNames[randomValue];
  let odds = calculateOdds(randomValue);

  // Decrement the quantity of the selected token
  chaosBagCopy[randomValue]--;

  // Remove the token from the availableTokens if its quantity reaches zero
  if (chaosBagCopy[randomValue] === 0) {
    availableTokens = availableTokens.filter(token => token !== randomValue);
  }

  // Add the drawn token to drawnTokens
  drawnTokens.push(randomValue);

  // Create a new img for the drawn token
  let tokenImg = document.createElement('img');
  tokenImg.className = className;
  htmlElements.tokenImage.className = className;

  if (className === "icon-token_bless_sealed" || className === "icon-token_curse_sealed") {
    availableTokens.splice(randomIndex, 1); // Remove the value from the availableTokens array
  }

  if (htmlElements.displayOddsCheckbox.checked) {
    htmlElements.contentContainer.textContent = `Odds: ${odds}`;
  } else {
    htmlElements.contentContainer.textContent = '';
  }
};

const modifyBag = () => {
  htmlElements.overlay.classList.toggle('overlay-visible');
  htmlElements.revealAnotherButton.disabled = true;
  showContents();  // I assume showContents() is already defined somewhere
};

const addToken = () => {
  let tokenName = "icon-token_" + htmlElements.tokenInput.value + "_sealed";
  if (tokenNames.includes(tokenName)) {
    let tokenIndex = tokenNames.indexOf(tokenName);
    if (tokenIndex !== -1) {
      chaosBag[tokenIndex] += 1;
    } else {
      alert('Invalid token name. Please select a valid token from the dropdown.');
    }
    showContents();
  } else {
    alert('Invalid token name. Please select a valid token from the dropdown.');
  }
};

const removeToken = () => {
  let tokenName = "icon-token_" + htmlElements.tokenInput.value + "_sealed";
  if (tokenNames.includes(tokenName)) {
    let tokenIndex = tokenNames.indexOf(tokenName);
    if (tokenIndex !== -1) {
      chaosBag[tokenIndex] = Math.max(0, chaosBag[tokenIndex] - 1);
    } else {
      alert('Invalid token name. Please select a valid token from the dropdown.');
    }
    showContents();
  } else {
    alert('Invalid token name. Please select a valid token from the dropdown.');
  }
};

const closeOverlay = () => {
  htmlElements.overlay.classList.remove('overlay-visible');
};

const toggleDisplayOdds = () => {
  if (htmlElements.displayOddsCheckbox.checked) {
    showOdds();
  } else {
    hideOdds();
  }
};

const changeCampaign = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  selectedCampaign = htmlElements.campaignSelector.value;
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  showContents();
};

const changeDifficulty = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  selectedDifficulty = htmlElements.difficultySelector.value;
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  showContents();
};

// Event Listeners
htmlElements.drawTokenButton.addEventListener('click', drawToken);
htmlElements.revealAnotherButton.addEventListener('click', revealAnotherToken);
htmlElements.modifyBagButton.addEventListener('click', modifyBag);
htmlElements.addTokenButton.addEventListener('click', addToken);
htmlElements.removeTokenButton.addEventListener('click', removeToken);
htmlElements.closeOverlayButton.addEventListener('click', closeOverlay);
htmlElements.displayOddsCheckbox.addEventListener('change', toggleDisplayOdds);
htmlElements.campaignSelector.addEventListener('change', changeCampaign);
htmlElements.difficultySelector.addEventListener('change', changeDifficulty);

// Initial setup
hideOdds();
htmlElements.revealAnotherButton.disabled = true;
---
Ingredients:
- 2.5 rice cooker cups water
- 1 rice cooker cup brown rice
- 1 tbsp butter
- 1 tsp salt
Steps:
- 1. Add ingredients to rice cooker
- 2. Run rice cooker with brown rice setting
---
**Index**:: [[Meal Prep]]

# Brown Rice
#### Ingredients (4 servings)
- 2 cups of brown jasmine rice
- 4.5 cups of water (slightly above the 2 line)
- 2 tsp kosher salt
- 2 tbsp butter 

For 2 servings (no leftovers)
- 1 cup of brown jasmine rice
- 2.5 cups of water
- 1 tsp kosher salt
- 1 tbsp butter 

#### Steps
1. Add ingredients to the rice cooker
2. Press brown rice
3. Wait for cooker to beep and serve when ready (takes about 60-70 minutes)
4. Store half of it away immediately so you don't overeat

#### Results
- 20200929: Used ingredients for 2 servings, came out delicious
- 20200902: Delicious
- 20200822: Not so great. Need to measure water with cups next time.
- 2020820: Really good! First time brown rice came out well
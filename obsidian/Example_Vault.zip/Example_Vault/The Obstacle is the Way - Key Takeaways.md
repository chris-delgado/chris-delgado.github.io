[[20221028 The Obstacle Is the Way]]

---
# The Obstacle is the Way - Key Takeaways

## Overview
### 1. Obstacles Are Opportunities
- We can see opportunity in every disaster, and transform that negative situation into an education, a skill set, or a fortune

#### Historical Example
- Eisenhower saw German blitzkrieg as an opportunity for Allied forces to bend, not break, and German forces to overextend, making themselves surrounded and vulnerable to flank attacks

### 2. Three Steps to Overcoming Obstacles
1. How we look at our specific problems; our attitude or approach (Perception)
2. The energy and creativity with which we actively break them down and turn them into opportunities (Action)
3. The cultivation and maintenance of an inner will that allows us to handle defeat and difficulty (Will)

#### In Other Words...
- First, see clearly
- Then, act correctly
- Finally, endure and accept the world as it is

## Perception
### 3. What Is Perception
- How we see and understand what occurs around us, and what we decide those events will mean
- It is applicable in each and every situation, impossible to obstruct, and can only be relinquished (given up)

### 4. The Discipline of Perception
When faced with seemingly insurmountable obstacles, we must try to:
- Be objective
- Control emotions and keep an even keel
- Choose to see the good in a situation
- Steady our nerves
- Ignore what disturbs or limits others
- Place things in perspective
- Revert to the present moment
- Focus on what can be controlled

### 5. Steady Your Nerves
- Nerve is defiance and acceptance: there is always a countermove, always an escape or a way through, so there is no reason to get worked up

### 6. Control Your Emotions
- Fear, bred mostly from unfamiliarity, is relieved by training and exposure which increase our tolerance for stress and uncertainty
- Fight the urge to panic and instead focus on only what you can change, on the task at hand
- Real strength lies in the control (domestication) of one's emotions, not in pretending they don't exist
- Constantly ask yourself "Do I need to freak out about this?"
- The answer must be "No, because I practiced for this situation and I can control myself" or "No, because I caught myself and I'm able to realize that that doesn't add anything constructive"

### 7. Apatheia
- from a- "without" and pathos "suffering" or "passion"
- Quite different from that of the modern English apathy, which has a distinctly negative connotation
- Better translated by the word equanimity, a calm that comes with the absence of irrational or extreme emotions
- Not the loss of feeling altogether, just the loss of the harmful, unhelpful kind

### 8. The Serenity Prayer
> God, grant me the serenity to accept the things I cannot change
> The courage to change the things I can,
> And the wisdom to know the difference
- The most harmful dragon we chase is the one that makes us think we can change things that are simply not ours to change
	- That someone decided not to fund your company, this isn't up to you, but the decision to refine and improve your pitch? That is.
	- That someone stole your idea or got to it first? No. To pivot, improve it, or fight for what's yours? Yes.

### 9. See Disaster as Opportunity
- If you're at the end of your rope and would rather quit, you actually have an opportunity to experiment with different solutions, try different tactics, or take on new projects all with a perfect safety net for yourself: quitting and getting out of there
- You might learn two things:
	1. That your instinct was wrong
	2. The kind of appetite for risk you really have

### 10. Prepare to Act
- The worst thing to happen is never the event, but the event and losing your head
- Perception precedes action; right action follows the right perspective
- The demand on you is this: once you see the world as it is, for what it is, you must act

## Action
### 11. What Is Action?
- Our movements and decisions which define us

### 12. The Discipline of Action
We can always (and only) greet our obstacles with:
- Energy
- Persistence
- A coherent and deliberate process
- Iteration and resilience
- Pragmatism
- A strategic vision
- Craftiness and savvy
- An eye for opportunity and pivotal moments

### 13. Create Your Own Momentum
- Stay moving. Always.
- Those who attack life with the most initiative and energy usually win
- The people who defy the odds and become great at things start. Anywhere. Anyhow.
- They don't care if the conditions are perfect or not, because they know that once they get started, they can make it work
- Reminds me of the importance of initiative in the game of chess

### 14. Minimum Viable Product
- In Silicon Valley, start-ups don't launch with polished, finished businesses
- Instead, they release their minimum viable product (MVP) which is the most basic version of their core idea with only one or two essential features
- The point is to immediately see how customers respond
- If that response is poor, they can fail cheaply and quickly, which avoids making or investing in a product customers do not want

#### Compared to The Old Way of Business
- Companies would guess what customers want from research and then produce those products in a lab, isolated and insulated from feedback, which reflects a fear of failure
- The MVP model embraces failure and feedback; it gets stronger by failure, dropping the features that don't work, that customers don't find interesting, and then focusing the developers' limited resources on improving the features that do

#### Great Entrepreneurs Are Never...
- Wedded to a position
- Afraid to lose a little of their investment
- Bitter or embarrassed
- Out of the game for long

### 15. Follow the Process
- Excellence is a matter of steps: excelling at this one, then that one, and then the one after that
- The process is about finishing; finishing the smallest task you have right in front of you and finishing it well
- We are A-to-Z thinkers, fretting about A, obsessing over Z, yet forgetting all about B through Y

### 16. Do Your Job and Do It Right
- Everything is a chance to do and be your best
- You're so busy thinking about the future, you don't take any pride in the tasks you're given right now
- To whatever we face, our job is to respond with:
	- Hard work
	- Honesty
	- Helping others as best we can
- If we do our best we can be proud of our choices and confident they're the right ones
- Reminds me of how Maynard James Keenan would put all his energy into that pet store he worked at

### 17. The Meaning of Life
- Psychologist and Holocaust survivor Viktor Frankl found presumptuousness in the age-old question "What is the meaning of life?"
- Instead, he said, the world is asking *you* that question
- It's your job to answer with your actions
- In every situation, life is asking us a question, and our actions are the answer
- Our job is simply to answer well

### 18. Take the Line of Least Expectation
- When your at your wit's end: take a step back, go around the problem, find some leverage, and approach from what is called "the line of least expectation"
- Having the advantage of size or strength or power is often the birthing ground for true and fatal weakness as the inertia of success makes it much harder to truly develop good technique
- You don't convince people by challenging their longest and most firmly held opinions
	- Instead, you find common ground and work from there
	- Or you look for leverage to make them listen
	- Or you create an alternative with so much support from other people that the opposition voluntarily abandons its views and joins your camp

### 19. Never Let a Crisis Go to Waste
- A crisis provides the opportunity for us to do things that you could not do before (e.g. perhaps you're stuck in bed recovering; now you have time to write)
- Do we accept this as an exclusively negative event, or can we get past whatever adversity it represents and mount an offensive?
- More precisely, can we see that this "problem" presents an opportunity for a solution that we have long been waiting for?

### 20. Prepare for None of It to Work
- Perceptions can be managed
- Actions can be directed
- We can always think clearly, respond creatively, look for opportunity, and seize the initiative
- What we can't do is control the world around us
- It's an infinitely elastic formula: In every situation, that which blocks our path actually presents a new path

## Will
### 21. What Is Will
- It is the strength to endure, contextualize, and derive meaning from the obstacles we cannot simply overcome (flipping the unflippable)
- If action is what we do when we still have some agency over our situation, the will is what we depend on when agency has all but disappeared

### 22. The Discipline of the Will
In every situation, we can always:
- Prepare ourselves for more difficult times
- Accept what we're unable to change
- Manage our expectations
- Persevere
- Learn to love our fate and what happens to us
- Protect our inner self, retreat into ourselves
- Submit to a greater, larger cause
- Remind ourselves of our own mortality
- Prepare to start the cycle once more

### 23. Mens sana in corpore sano
- A Latin phrase, usually translated as "a healthy mind in a healthy body"
- The phrase is widely used in sporting and educational contexts to express the theory that physical exercise is an important or essential part of mental and psychological well-being
- In other words, we craft our spiritual strength through physical exercise, and our physical hardiness through mental practice

### 24. Anticipate Things Going Wrong
- The only guarantee is that things will go wrong; the only thing we can use to mitigate this is anticipation because the only variable we control completely is ourselves
- About the worst thing that can happen is not something going wrong, but something going wrong and catching you by surprise because unexpected failure is discouraging and being beaten back hurts
- The person who has rehearsed what could go wrong will not be caught by surprise; the person ready to be disappointed won't be; they will have the strength to bear it
- Sometimes the only answer to "What if..." is "It will suck but we'll be okay"
- Premortems are a useful exercise for this

### 25. Constraints Are Good
- Especially if we can accept them and let them direct us
- They push us to places and to develop skills that we'd otherwise never have pursued

### 26. Amor Fati
- A Latin phrase that may be translated as "love of fate" or "love of one's fate"
- It is used to describe an attitude in which one sees everything that happens in one's life, including suffering and loss, as good or, at the very least, necessary
- It is the act of turning what we must do into what we get to do
- Love the opportunity to prove yourself, to perform for people, whether they want you to succeed or not
- The goal is:
	- NOT: I'm okay with this
	- NOT: I think I feel good about this
	- BUT: I feel great about it (Because if it happened, then it was meant to happen, and I am glad that it did when it did. I am meant to make the best of it.)

### 27. Perseverance
- Persistence is directing everything at one problem until it breaks; attempting to solve some difficult problem with dogged determination and hammering until the break occurs
- Perseverance is something larger; it's about what happens not just in round one but in round two and every round after - and then the fight after that and the fight after, until the end
- Life is not one obstacle but many - what's required of us is not some focus on a single facet of a problem, but a determination that we will get to where we need to go, somehow, someway, and nothing will stop us
- Persistence is an action; Perseverance is a matter of will
- Persist and Persevere

### 28. Focus on Others
- Shared purpose gives us strength
- When we focus on others, on helping them or simply providing a good example, our own personal fears and troubles will diminish
- With fear or heartache no longer our primary concern, we don't have time for it
- Stop pretending that what you're going through is somehow special or unfair

### 29. Memento mori
- "Remember that you are mortal"
- Death doesn't make life pointless, but rather purposeful

### 30. Prepare to Start Again
- Elysium is a myth; one does not overcome an obstacle to enter the land of no obstacles
- On the contrary, the more you accomplish, the more things will stand in your way

## Final Thoughts
- The lessons in this book didn't sink in until I started going over my highlights and really reflecting on it - not the first time this has happened but certainly the most poignant
- I also didn't realize the structure of this book until reviewing my highlights and taking notes on it
	- First chapter of each section: What is...
	- Second chapter of each section: The Discipline of...
	- Final chapter of each section: Prepare to...
- I still don't feel as though I've internalized much of what the book has to offer; each of my 30 takeaways above can really be delved into much more deeply (most of them have dedicated chapters after all)
- Looking forward to read more of Holiday's books and getting further immersed in Stoicism
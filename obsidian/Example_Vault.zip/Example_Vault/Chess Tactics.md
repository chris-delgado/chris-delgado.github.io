[[Archive]]
[Lichess Practice](https://lichess.org/practice)
[Tactics Resources](https://www.reddit.com/r/chess/wiki/resources#wiki_tactics)
[Dan Heisman Tactics Books](https://www.danheisman.com/recommended-book-lists.html)

# Chess Tactics
Attraction
Counting Chess Tactic
Deflection
Discovered Attack
Double Check
Fork
Greek Gift
Interference
Interposition
Overloaded Pieces
Pin
Removal of the Guard
Skewer
X-Ray
Zugzwang
Zwischenzug

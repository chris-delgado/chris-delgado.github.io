---
Goal: Plan a trip to New Orleans
Outcome: Fantastic, well done
Deadline: 2022-09-15
Status: Complete
---
**Index**:: [[Projects]]
**Areas**:: [[Travel]]
**Deliverable**:: [[2022 New Orleans - Itinerary|Itinerary]]
**Start**:: [[2022-08-24]]
**End**:: [[2022-09-22]]

# Plan Trip to New Orleans
## Milestones

## Next Steps

## Resources
[[2022 New Orleans]]
[[Resources]]

# Templates
[[Book Note Template]]
[[Daily Note Template]]
[[Monthly Review Template]]
[[Project Note Template]]
[[2022 New Orleans]]
[Jazzy Pass](https://www.norta.com/ride-with-us/how-to-pay/jazzy-passes)

---
# 2022 New Orleans - Streetcars
- They are not called trolleys!
- Streetcars fare is $1.25 and must be paid with exact change when you board 
- One, three, and 31-day unlimited ride “Jazzy Passes” are also available for $3, $9, and $55 respectively.
- Download the RTA's Le Pass app and pay your fare instantly from your phone
- 7 day jazzy pass on the app will cover street car fare
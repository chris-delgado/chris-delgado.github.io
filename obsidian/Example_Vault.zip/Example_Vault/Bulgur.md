---
Ingredients:
- 340g bulgur (half a Bob's Red Mill)
- 680mL water
- 1 tbsp salt
Steps:
- 1. Combine ingredients and bring to a boil
- 2. Lower to a simmer and cover for 12 minutes
---
**Index**:: [[Meal Prep]]

# Bulgur
## Ingredients
[[Resources]]

# Daily Note
---
Ingredients:
- 340g farro (half bob's red mill bag)
- 2720mL water
- 1 tbsp salt
Steps: 
- 1. Combine ingredients and bring to a boil
- 2. Simmer for 30 minutes at medium high heat then drain
---
**Index**:: [[Meal Prep]]

# Farro
## Ingredients
- 1 cup farro (update this to half the bag)
- 8 cups water (8:1 ratio)
- .5 tbsp salt

## Steps
- Boil then simmer for 30 minute, then drain
---
Ingredients:
- russet or sweet potatoes
Steps:
- 1. Sous vide at 190F for 2 hours
---
**Index**:: [[Meal Prep]]
[[Sous Vide]]

# Sous Vide Potatoes
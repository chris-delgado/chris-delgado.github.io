---
Goal: Upload myself playing Mendelssohn's Regrets by early December
Outcome: Looks good. I like how I used separate colors for the black and white notes.
Deadline: 2022-12-06
Status: Complete
---
**Index**:: [[Projects]]
**Areas**:: [[Piano]]
**Deliverable**:: [YouTube](https://youtu.be/tCBzAiJPSp8)
**Start**:: [[2022-07-15]]
**End**:: [[2022-11-15]]

# Learn Regrets
## Milestones
[[2022-11-05]] Began focusing more on interpretation and less on tempo
[[2022-11-14]] Recorded it
[[2022-11-15]] Edited MIDI and video, uploaded to YouTube

## Next Steps
---
Ingredients:
- 65g spinach
- 100g cucumber
- 1 whole tomato
- .5 tbsp extra virgin olive oil
- .5 tbsp balsamic vinegar
- salt, pepper, oregano
Steps:
- 1. Combine ingredients in bowl
- 2. Top with a protein (e.g. chicken breast)
---
**Index**:: [[Meal Prep]]

# Simple Salad
## Ingredients:
- 65g Spinach
- 100g Cucumber
- 1 whole Tomato
- .5 tbsp Extra Virgin Olive Oil
- .5 tbsp Balsamic Vinegar
- Optional: Salt, Pepper, Oregano

## Steps
1. Combine ingredients in bowl
2. Top with a protein (e.g. chicken breast)
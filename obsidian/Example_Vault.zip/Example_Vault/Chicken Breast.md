---
Alias: Sous Vide Chicken Breast
Ingredients:
- chicken breast
- salt & pepper
Steps:
- 1. Slice breasts in half lengthwise
- 2. Season generously w/ salt & pepper 
- 3. Vacuum seal, freeze if needed
- 4. Sous vide 4h @147F
---
**Index**:: [[Meal Prep]]
[[Sous Vide]]
[Serious Eats](https://www.seriouseats.com/sous-vide-chicken-breast-recipe)

# Chicken Breast
## Sous Vide
- Slice chicken each chicken breast in half (each half comes out to about 125g)
- Generous Salt and Pepper before sealing in bag
- 4h @147F
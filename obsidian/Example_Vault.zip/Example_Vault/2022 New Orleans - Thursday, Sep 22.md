[[2022 New Orleans - Itinerary]]

---
# Thursday, Sep 22
## 7 AM: Breakfast
- Breakfast in hotel or see [[2022 New Orleans - Cafes#CBD Warehouse District]] for cafes nearby

##  8:30 AM: Checkout & Uber
- Usually a 25-40 minute drive to Louis Armstrong International Airport

## 11 AM: Flight
- Depart 11:05AM
- Arrive 3:07PM

## 4 PM: Uber Home
- Usually a 35-60 minute drive at this time
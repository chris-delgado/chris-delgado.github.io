[[20210515 Atomic Habits]]

---
# Atomic Habits - Key Takeaways
## Fundamentals
- Habits are the compound interest of self-improvement (an "aggregation of marginal gains")
- Habits appear to make no difference until you cross a critical threshold and unlock a new level of performance (aka breaking through the "plateau of latent potential")
- Forget about goals and focus on systems (process) instead

### Identity-Based Habits
- The ultimate form of instrinsic motivation is when a habit becomes part of your identity (I'm someone who WANTS this vs. someone who IS this)
- Habits are how you embody your identity; every action is a vote for the type of person you wish to become

### The Habit Loop
- Cue > Craving > Response > Reward

### How to Create a Good Habit
- Make it obvious, attractive, easy, and satisfying

### How to Break a Bad Habit
Make it invisible, unattractive, difficult, and unsatisfying

## Laws of Behavior Change
### Make It Obvious
- Create a habits scorecard to raise awareness
	- Categorize habits by how they benefit you in the long run; are they votes for or against your desired identity? Example: Wake Up = Exercise + Watch TV - etc.
- Use implementation intentions to pair a new habit with a specific time and location: I will BEHAVIOR at TIME in LOCATION
- Use habit stacking to pair new habits with existing ones: After CURRENT HABIT, I will NEW HABIT
- Start thinking about your environment as filled with relationships and how you interact with the spaces around you (ONE SPACE, ONE USE)

### Make it Invisible
- It's easier to avoid temptation than resist it (self-control is a short-term strategy), so eliminate bad habits by reducing exposure to their cues

### Make It Attractive
- Temptation bundling: Pair an action you want to do with an action you need to do; After HABIT I NEED, I will HABIT I WANT
- One of the most effective things you can do to build better habits is join a culture where (1) your desired behavior is the normal behavior and (2) you already have something in common with the group
- Create a motivation ritual by associating a behavior with something you enjoy to trigger a particular feeling that can be used immediately before a difficult habit/task. Examples:
	- Stretching before a workout puts you in the right mental state
	- Breath and smile before petting the cat to create a cue to be happy (use it whenever you need to change your emotional state)
	- Putting on heaphones before taking notes to increase focus and concentration

### Make It Unattractive
- Use mindset shifts to re-frame your outlook
	- Example: During meditation, each thought that comes into your head is an opportunity to practice returning to your breath

### Make It Easy
- The most effective form of learning is practice, not planning; thus, the amount of time you perform a habit is not as important as the number of times you have performed it
- Optimize your "decisive moments" each day
	- Example: Putting on your workout clothes or crash on the couch could determine how you spend your evening
- Prime your environment to make future actions easier. Examples:
	- Want to improve your diet? Meal prep
	- Want to exercise? Set out your workout equipment ahead of time
	- Want to draw more? Set out drawing equipment ahead of time
- Two minute rule: when you start a new habit, it should take less than two minutes to do (this is your "gateway habit" that naturally leads you down to a more productive path)

### Make It Difficult
- The ultimate way to lock in future behavior is to automate your habits, e.g. by using technology or making onetime choices like enrolling in an automatic savings plan
	- Requires more work to get out of the good habit than it does to get started on it
	- Examples: Website blocker, automatic rx refill, use smaller plates to reduce caloric intake, unsubscribe from emails, outlet timer to cutoff internet after a certain hour

### Make It Satisfying
- The best approach to making your habit satisfying is reinforcement
	- Can be especially helpful when dealing with habits of avoidance (behaviors you want to stop doing)
	- Make avoidance visible. Example: open a checking account and label it something you want that you identify with; add to it whenever you successfully avoid a craving
	- Select short-term rewards that reinforce your identity rather than conflict with it
		- If your reward for exercising is a bowl of ice cream, then you're casting conflicting votes (an alignment of short-term reward with long-term reward would instead be a massage)
- Habit trackers can make your habits satisfying by providing clear evidence of your progress
	- Never miss twice. If you miss a day, try to get back on track as quickly as possible (missing once is an accident; missing twice is the start of a new habit)
	- The dark side of tracking is that we become driven by the number rather than the purpose behind it
		- Examples: Caring more about getting 10,000 steps than being healthy, focusing on working long hours rather than getting meaningful work done, teaching for standardized tests instead of emphasizing learning, curiosity, and critical thinking

### Make It Unsatisfying
- An accountability partner can create an immediate cost to inaction as we care deeply what others think and don't want others to have a lesser opinion of us
- A habit contract can be used to add a social cost to any behavior: makes the costs of violating your promises public and painful

## Advanced Tactics
### Aligning Habits With Your Strengths
- Habits are easier to perform and more satisfying to stick with when they align with your natural inclinations and abilities
- To narrow in on the habits and areas most satisfying to you, ask yourself:
	1.  What feels like fun to me, but work to others?
	2.  What makes me lose track of time?
	3.  Where do I get greater returns than the average person?
	4.  What comes naturally to me?
- Explore/exploit trade-off: in the beginning of a new activity, there should be a period of exploration, after which you shift your focus to the best solution that you've found (but keep experimenting occasionally)

### How to Stay Motivated
- The Goldilocks Rule: Humans experience peak motivation when working on tasks that are right on the edge of their current abilities (aka achieving flow)
- The greatest threat to success is not failure but boredom
	- Successful people feel the same lack of motivation as everyone else; the difference is they still find a way to show up
	- At some point it comes down to who can handle the boredom of training every day, doing the same lifts over and over and over
	- You have to fall in love with boredom

### Mitigating the Downsides of Good Habits
- The upside of habits is we can do things without thinking; the downside is we stop paying attention to little errors
- Reflection and review is a process that allows you to remain conscious of your performance over time so you can continue to refine and improve (Habits + Deliberate Practice = Mastery)
	- Become aware of your mistakes, otherwise we create excuses, rationalizations, and lie to ourselves
- Annual Review (reflections on the previous year):
	- What went well this year?
	- What didn't go so well this year?
	- What did I learn?
- Integrity Report (6 months after Annual Review):
	- What are the core values that drive my life and work?
	- How am I living and working with integrity right now?
	- How can I set a higher standard in the future?
- To mitigate losses of identity, redefine yourself such that you get to keep important aspects of your identity ever if your particular role changes; example: I'm an athlete becomes I'm the type of person who is mentally tough and loves a physical challenge

## Little Lessons
1. Awareness Comes Before Desire
2. Happiness is Simply the Absence of Desire
3. It is the Idea of Pleasure That We Chase
4. Peace Occurs When You Don't Turn Your Observations Into Problems
5. With a Big Enough Why You Can Overcome Any How
6. --> Being Curious is Better than Being Smart <--
7. Emotions Drive Behavior
8. We Can Only Be Rational and Logical After We Have Been Emotional
9. Your Response Tends to Follow Your Emotions
10. Suffering Drives Progress
11. Your Actions Reveal How Badly You Want Something
12. Reward is on the Other Side of Sacrifice
13. Self-Control is Difficult Because It is Not Satisfying
14. Our Expectations Determine Our Satisfaction
15. The Pain of Failure Correlates to the Height of Expectation
16. Feelings Come Both Before and After the Behavior
17. Desire Initiates, Pleasure Sustains
18. Hope Declines with Experience and is Replaced by Acceptance

## Tools & Strategies
- Habit Loop
- Four Laws of Behavior Change

### 1st Law
- Habit Scorecard
- Implementation Intentions
- Habit Stacking
- One Space, One Use
- Reduce Exposure to Bad Habit Cues

### 2nd Law
- Temptation Bundling
- Join Culture Where Desired Behavior is Normal
- Motivation Ritual
- Reframe Your Mindset

### 3rd Law
- Reduce Friction for Good Habits
- Prime the Environment
- Decisive Moments
- Two Minute Rule
- Automate Your Habits
- Increase Friction for Bad Habits
- Commitment Devices

### 4th Law
- Reinforcement
- Habit Tracker
- Never Miss Twice
- Accountability Partner
- Habit Contract

## Final Thoughts
- One of my favorite self improvement books, checked off a lot of boxes of things I was already doing in my life
- Definitely want to review these notes from time to time to refresh my knowledge of habits
- Much more of the brain is devoted to wanting (craving) things than it is to liking them (this is why satisfying food cravings always feels like such a let down, or why jumping back into an old video game is never as much fun as you remember)
- Some ideas I got from it to implement:
	1. Identify your triggers/cravings
	2. Set aside all the food for next day (containers for nuts/fruit?) 
	3. On deck for next projects
	4. Paper clip strategy for case closures?
	5. Unsubscribe from emails
	6. Auto rx refill
	7. Annual Review & Integrity Report
	8. Open a checking account and label it something you want that you identify with; add to it whenever you successfully avoid a craving
	9. Ask myself the 4 questions to figure out the best habits for me
	10. Wear same clothes each day
	11. Lay out clothes in bathroom for rest of the week
	12. Re-use salad container as your dish

#### 4 Questions
1.  What feels like fun to me, but work to others?
	- Paying off debt, exercising, piano, guitar, studying chess, notetaking, analyzing, flashcards, fasting, organization, simplifying
2.  What makes me lose track of time?
	- Music, reading, chess, notetaking
3.  Where do I get greater returns than the average person?
	- Technology, note taking, healthy lifestyle, 
4.  What comes naturally to me?
	- Notetaking, guitar kind of, studying, technology
const tokenNames = [
  "icon-token_1_sealed",
  "icon-token_0_sealed",
  "icon-token_-1_sealed",
  "icon-token_-2_sealed",
  "icon-token_-3_sealed",
  "icon-token_-4_sealed",
  "icon-token_-5_sealed",
  "icon-token_-6_sealed",
  "icon-token_-7_sealed",
  "icon-token_-8_sealed",
  "icon-token_skull_highlight",
  "icon-token_cultist_highlight",
  "icon-token_tablet_highlight",
  "icon-token_elder_thing_highlight",
  "icon-token_auto_fail_highlight",
  "icon-token_elder_sign_highlight",
  "icon-token_frost_sealed",
  "icon-token_bless_sealed",
  "icon-token_curse_sealed"
];

const presets = {
  'The Night of the Zealot': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 1, 1, 0, 1, 1, 0, 0, 0]
  },
  'The Dunwich Legacy': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 1, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 1, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Path to Carcosa': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 3, 0, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 3, 0, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Forgotten Age': {
    easy: [2, 3, 2, 1, 1, 0, 0, 0, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    standard: [1, 3, 1, 2, 1, 0, 1, 0, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    hard: [1, 2, 1, 1, 2, 1, 0, 1, 0, 0, 2, 0, 0, 1, 1, 1, 0, 0, 0],
    expert: [0, 1, 1, 2, 2, 2, 0, 1, 0, 1, 2, 0, 0, 1, 1, 1, 0, 0, 0]
  },
  'The Circle Undone': {
    easy: [2, 3, 2, 1, 1, 0, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 2, 2, 1, 1, 0, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    hard: [0, 2, 2, 2, 1, 1, 1, 0, 0, 0, 2, 0, 0, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 1, 1, 0, 1, 0, 1, 2, 0, 0, 0, 1, 1, 0, 0, 0]
  },
  'The Dream-Eaters': {
    easy: [2, 3, 2, 2, 0, 0, 0, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 2, 2, 1, 1, 0, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    hard: [0, 2, 2, 2, 2, 1, 1, 0, 0, 0, 0, 1, 2, 0, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 1, 2, 1, 1, 0, 1, 0, 1, 2, 0, 1, 1, 0, 0, 0]
  },
  'The Innsmouth Conspiracy': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 2, 2, 2, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 2, 2, 2, 1, 1, 0, 0, 0]
  },
  'Edge of the Earth': {
    easy: [3, 2, 3, 2, 0, 0, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 1, 1, 0, 1, 1, 1, 0, 0],
    hard: [0, 2, 2, 2, 1, 2, 1, 0, 0, 0, 2, 1, 1, 0, 1, 1, 2, 0, 0],
    expert: [0, 1, 1, 2, 1, 2, 1, 0, 1, 0, 2, 1, 1, 0, 1, 1, 3, 0, 0]
  },
  'The Scarlet Keys': {
    easy: [2, 3, 3, 2, 0, 0, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    standard: [1, 2, 3, 2, 1, 1, 0, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    hard: [0, 3, 2, 2, 2, 1, 1, 0, 0, 0, 2, 0, 1, 1, 1, 1, 0, 0, 0],
    expert: [0, 1, 2, 2, 2, 2, 1, 1, 0, 1, 2, 0, 1, 1, 1, 1, 0, 0, 0]
  },
};

const scenarios = {
  'The Night of the Zealot': ['The Gathering', 'The Midnight Masks', 'The Devourer Below'],
  'The Dunwich Legacy': ['Extracurricular Activity', 'The House Always Wins', 'The Miskatonic Museum', 'The Essex County Express', 'Blood on the Altar', 'Undimensioned and Unseen', 'Where Doom Awaits', 'Lost in Time and Space'],
  'The Path to Carcosa': ['Curtain Call', 'The Last King', 'Echoes of the Past', 'The Unspeakable Oath', 'A Phantom of Truth', 'The Pallid Mask', 'Black Stars Rise', 'Dim Carcosa'],
  'The Forgotten Age': ['The Untamed Wilds', 'The Doom of Eztli', 'Threads of Fate', 'The Boundary Beyond', 'Heart of the Elders', 'The City of Archives', 'The Depths of Yoth', 'Shattered Aeons', 'Turn Back Time'],
  'The Circle Undone': ['Disappearance at the Twilight Estate', 'The Witching Hour', 'The Secret Name', 'The Wages of Sin', 'For the Greater Good', 'Union and Disillusion', 'In the Clutches of Chaos', 'Before the Black Throne'],
  'The Dream-Eaters': ['Beyond the Gates of Sleep', 'Waking Nightmare', 'The Search for Kadath', 'A Thousand Shapes of Horror', 'Dark Side of the Moon', 'Point of No Return', 'Where the Gods Dwell', 'Weaver of the Cosmos'],
  'The Innsmouth Conspiracy': ['The Pit of Despair', 'The Vanishing of Elina Harper', 'In Too Deep', 'Devil Reef', 'Horror in High Gear', 'A Light in the Fog', 'The Lair of Dagon', 'Into the Maelstrom'],
  'Edge of the Earth': ['Ice and Death', 'Fatal Mirage', 'To the Forbidden Peaks', 'City of the Elder Things', 'The Heart of Madness'],
  'The Scarlet Keys': ['Riddles and Rain', 'Dancing Mad', 'Dead Heat', 'Dealings in the Dark', 'Dogs of War', 'On Thin Ice', 'Sanguine Shadows', 'Shades of Suffering', 'Without a Trace', 'Congross of the Keys']
};

// HTML Elements
const htmlElements = {
  contentContainer: document.getElementById('drawn-token-value'),
  tokenImage: document.getElementById('token-image'),
  campaignSelector: document.getElementById('campaign'),
  scenarioSelector: document.getElementById('scenario'),
  difficultySelector: document.getElementById('difficulty'),
  drawTokenButton: document.getElementById('draw-token-button'),
  addTokenButton: document.getElementById('add-token-button'),
  removeTokenButton: document.getElementById('remove-token-button'),
  tokenInput: document.getElementById('token-input'),
  modifyBagButton: document.getElementById('modify-bag-button'),
  overlay: document.getElementById('overlay'),
  closeOverlayButton: document.getElementById('close-overlay'),
  bagContents: document.getElementById('bag-contents'),
  displayOddsCheckbox: document.getElementById('display-odds'),
  displayReferenceCheckbox: document.getElementById('display-reference'),
  revealAnotherButton: document.getElementById('reveal-another-button'),
  historyButton: document.getElementById('history-button'),
  instructionsElement: document.getElementById('instructions'),
  subtitle: document.getElementById('subtitle'),
  closeHistoryOverlayButton: document.getElementById('close-history-overlay'),
  historyOverlay: document.getElementById('history-overlay'),
  drawHistory: document.getElementById('draw-history'),
  drawHistoryTotal: document.getElementById('draw-history-total'),
  saveButton: document.getElementById('save-button'),
  loadButton: document.getElementById('load-button'),
  profile: document.getElementById('profile'),
  deleteButton: document.getElementById('delete-button'),
  renameButton: document.getElementById('rename-button'),
  clearHistoryButton: document.getElementById('clear-history-button'),
  referenceText: document.getElementById('token-reference-text')
};

// Variables
let profileName;
let drawHistory = [];
let drawnTokens = [];
let tokenValues = [];
let selectedCampaign = 'The Night of the Zealot';
let selectedDifficulty = 'easy';
let selectedScenario = 'The Gathering';
let chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
let chaosBagCopy = [...chaosBag];

// Functions
const calculateOdds = tokenValue => {
  const [tokenCount, totalTokens] = [chaosBagCopy[tokenValue], chaosBagCopy.reduce((sum, quantity) => sum + quantity, 0)];
  const odds = Math.round((tokenCount / totalTokens) * 1000) / 10;
  return `${odds}%`;
};

const showOdds = () => {
  htmlElements.contentContainer.style.display = 'block';
};

const hideOdds = () => {
  htmlElements.contentContainer.style.display = 'none';
};

const resetChaosBag = () => {
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  drawnTokens = [];
};

const showContents = () => {
  htmlElements.tokenImage.className = '';
  let tokenValues = [];
  chaosBagCopy = [...chaosBag];

  chaosBag.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  htmlElements.contentContainer.innerHTML = '';
  htmlElements.bagContents.innerHTML = '';

  let row = document.createElement('div');
  row.className = 'row';
  htmlElements.bagContents.appendChild(row);

  tokenValues.forEach(function(value) {
    let token = document.createElement('span');
    token.className = tokenNames[value];
    row.appendChild(token);
  });

  if (htmlElements.displayOddsCheckbox.checked) {
    showOdds();
  } else {
    hideOdds();
  }
  updateBagTotal();
};

const updateSubtitle = () => {
  htmlElements.subtitle.textContent = `${selectedCampaign} | ${selectedScenario} | ${selectedDifficulty}`;
};

const updateBagTotal = () => {
  const bagTotalElement = document.getElementById('bag-total');
  const totalTokens = chaosBag.reduce((sum, quantity) => sum + quantity, 0);
  bagTotalElement.textContent = `${totalTokens}`;
};

const clearHistory = () => {
  drawHistory = [];
  htmlElements.drawHistory.innerHTML = '';
  htmlElements.drawHistoryTotal.textContent = `${drawHistory.length}`;
};

const updateScenarioDropdown = () => {
  // Get the currently selected campaign
  let selectedCampaign = htmlElements.campaignSelector.value;

  // Clear the current options
  htmlElements.scenarioSelector.innerHTML = '';

  // Get the new scenarios
  let campaignScenarios = scenarios[selectedCampaign];

  // Create and append new option elements for each scenario
  for (let scenario of campaignScenarios) {
    let option = document.createElement('option');
    option.text = scenario;
    option.value = scenario;
    htmlElements.scenarioSelector.appendChild(option);
  }
};

const generateReference = (tokenValue, scenario, difficulty) => {
  const skull = 'icon-token_skull_highlight';
  const cultist = 'icon-token_cultist_highlight';
  const tablet = 'icon-token_tablet_highlight';
  const elderThing = 'icon-token_elder_thing_highlight';
  /*const difficultyLevels = {
    'easy': 'front',
    'standard': 'front',
    'hard': 'back',
    'expert': 'back',
  };*/

  //const normalizedDifficulty = difficulty === 'easy' || difficulty === 'standard' ? 'front' : difficulty === 'hard' || difficulty === 'expert' ? 'back' : difficultyLevels[difficulty] || difficulty;
  const normalizedDifficulty = difficulty === 'easy' || difficulty === 'standard' ? 'front' : 'back'

  const references = {
    // The Night of the Zealot
    [`${skull}_The Gathering_front`]: "-X. X is the number of Ghoul enemies at your location.",
    [`${cultist}_The Gathering_front`]: "-1. If you fail, take 1 horror.",
    [`${tablet}_The Gathering_front`]: "-2. If there is a Ghoul Enemy at your location, take 1 damage.",
    [`${skull}_The Gathering_back`]: "-2. If you fail, after this skill test, search the encounter deck and discard pile for a Ghoul enemy, and draw it. Shuffle the encounter deck.",
    [`${cultist}_The Gathering_back`]: "Reveal another token. If you fail, take 2 horror.",
    [`${tablet}_The Gathering_back`]: "-4. If there is a Ghoul Enemy at your location, take 1 damage and 1 horror.",

    [`${skull}_The Midnight Masks_front`]: "-X. X is the highest number of doom on a Cultist enemy in play.",
    [`${cultist}_The Midnight Masks_front`]: "-2. Place 1 doom on the nearest Cultist enemy.",
    [`${tablet}_The Midnight Masks_front`]: "-3. If you fail, place 1 of your clues on your location.",
    [`${skull}_The Midnight Masks_back`]: "-X. X is the total number of doom in play.",
    [`${cultist}_The Midnight Masks_back`]: "-2. Place 1 doom on each Cultist enemy in play. If there are no Cultist enemies in play, reveal another token.",
    [`${tablet}_The Midnight Masks_back`]: "-4. If you fail, place all your clues on your location.",

    [`${skull}_The Devourer Below_front`]: "-X. X is the number of Monster enemies in play.",
    [`${cultist}_The Devourer Below_front`]: "-2. Place 1 doom on the nearest enemy.",
    [`${tablet}_The Devourer Below_front`]: "-3. If there is a Monster enemy at your location, take 1 damage.",
    [`${elderThing}_The Devourer Below_front`]: "-5. If there is an Ancient One enemy in play, reveal another",
    [`${skull}_The Devourer Below_back`]: "-3. If you fail, after this skill test, search the encounter deck and discard pile for a Monster enemy, and draw it. Shuffle the encounter deck.",
    [`${cultist}_The Devourer Below_back`]: "-4. Place 2 doom on the nearest enemy.",
    [`${tablet}_The Devourer Below_back`]: "-5. If there is a Monster enemy at your location, take 1 damage and 1 horror.",
    [`${elderThing}_The Devourer Below_back`]: "-7. If there is an Ancient One enemy in play, reveal another token.",

    // The Dunwich Legacy
    [`${skull}_Extracurricular Activity_front`]: "-1. If you fail, discard the top 3 cards of your deck.",
    [`${cultist}_Extracurricular Activity_front`]: "-1 (-3 instead if there are 10 or more cards in your discard pile).",
    [`${elderThing}_Extracurricular Activity_front`]: "-X. Discard the top 2 cards of your deck. X is the total printed cost of those discarded cards.",
    [`${skull}_Extracurricular Activity_back`]: "-2. If you fail, discard the top 5 cards of your deck.",
    [`${cultist}_Extracurricular Activity_back`]: "-1 (-5 instead if there are 10 or more cards in your discard pile).",
    [`${elderThing}_Extracurricular Activity_back`]: "-X. Discard the top 3 cards of your deck. X is the total printed cost of those discarded cards.",

    [`${skull}_The House Always Wins_front`]: "-2. You may spend 2 resources to treat this token as a 0, instead.",
    [`${cultist}_The House Always Wins_front`]: "-3. If you succeed, gain 3 resources.",
    [`${tablet}_The House Always Wins_front`]: "-2. If you fail, discard 3 resources.",
    [`${skull}_The House Always Wins_back`]: "-3. You may spend 3 resources to treat this token as a 0, instead.",
    [`${cultist}_The House Always Wins_back`]: "-3. If you fail, discard 3 resources.",
    [`${tablet}_The House Always Wins_back`]: "-2. Discard 3 resources.",

    [`${skull}_The Miskatonic Museum_front`]: "-1 (-3 instead if Hunting Horror is at your location.)",
    [`${cultist}_The Miskatonic Museum_front`]: "-1. If you fail, search the encounter deck, discard pile, and the void for Hunting Horror and spawn it at your location, if able.",
    [`${tablet}_The Miskatonic Museum_front`]: "-2. Return 1 of your clues to your current location.",
    [`${elderThing}_The Miskatonic Museum_front`]: "-3. If you fail, discard an asset you control.",
    [`${skull}_The Miskatonic Museum_back`]: "-2 (-4 instead if Hunting Horror is at your location.)",
    [`${cultist}_The Miskatonic Museum_back`]: "-3. If you fail, search the encounter deck, discard pile, and the void for Hunting Horror and spawn it at your location, if able.",
    [`${tablet}_The Miskatonic Museum_back`]: "-4. If Hunting Horror is at your location, it immediately attacks you.",
    [`${elderThing}_The Miskatonic Museum_back`]: "-5. If you fail, discard an asset you control.",

    [`${skull}_The Essex County Express_front`]: "-X. X is the current Agenda #.",
    [`${cultist}_The Essex County Express_front`]: "-1. If you fail and it is your turn, lose all remaining actions and end your turn immediately.",
    [`${tablet}_The Essex County Express_front`]: "-2. Add 1 doom token to the nearest Cultist enemy.",
    [`${elderThing}_The Essex County Express_front`]: "-3. If you fail, choose and discard a card from your hand.",
    [`${skull}_The Essex County Express_back`]: "-X. X is 1 more than the current Agenda #.",
    [`${cultist}_The Essex County Express_back`]: "Reveal another token. If you fail and it is your turn, lose all remaining actions and end your turn immediately.",
    [`${tablet}_The Essex County Express_back`]: "-4. Add 1 doom token to each Cultist enemy in play.",
    [`${elderThing}_The Essex County Express_back`]: "-3. If you fail, choose and discard a card from your hand for each point you failed by.",

    [`${skull}_Blood on the Altar_front`]: "-1 for each location in play with no encounter card underneath it (max -4).",
    [`${cultist}_Blood on the Altar_front`]: "-2. If you fail, add 1 clue from the token pool to your location.",
    [`${tablet}_Blood on the Altar_front`]: "-2. If you are in the Hidden Chamber, reveal another token.",
    [`${elderThing}_Blood on the Altar_front`]: "-3. If you fail, place 1 doom on the current agenda.",
    [`${skull}_Blood on the Altar_back`]: "-1 for each location in play with no encounter card underneath it.",
    [`${cultist}_Blood on the Altar_back`]: "-4. If you fail, add 1 clue from the token pool to your location.",
    [`${tablet}_Blood on the Altar_back`]: "-3. Reveal another token.",
    [`${elderThing}_Blood on the Altar_back`]: "-3. Place 1 doom on the current agenda.",

    [`${skull}_Undimensioned and Unseen_front`]: "-1 for each Brood of Yog-Sothoth in play.",
    [`${cultist}_Undimensioned and Unseen_front`]: "Reveal another token. If you fail this test, take 1 horror.",
    [`${tablet}_Undimensioned and Unseen_front`]: "0. You must either remove all clue tokens from a Brood of Yog-Sothoth in play, or this token's modifier is -4 instead.",
    [`${elderThing}_Undimensioned and Unseen_front`]: "-3. If this token is revealed during an attack or evasion attempt against a Brood of Yog-Sothoth, it immediately attacks you.",
    [`${skull}_Undimensioned and Unseen_back`]: "-2 for each Brood of Yog-Sothoth in play.",
    [`${cultist}_Undimensioned and Unseen_back`]: "Reveal another token. If you fail this test, take 1 horror and 1 damage.",
    [`${tablet}_Undimensioned and Unseen_back`]: "0. You must either remove all clue tokens from a Brood of Yog-Sothoth in play, or this test automatically fails.",
    [`${elderThing}_Undimensioned and Unseen_back`]: "-5. If this token is revealed during an attack or evasion attempt against a Brood of Yog-Sothoth, it immediately attacks you.",

    [`${skull}_Where Doom Awaits_front`]: "-1 (-3 instead if you are at an Altered location).",
    [`${cultist}_Where Doom Awaits_front`]: "Reveal another token. Cancel the effects and icons of each skill card committed to this test.",
    [`${tablet}_Where Doom Awaits_front`]: "-2 (-4 instead if it is Agenda 2).",
    [`${elderThing}_Where Doom Awaits_front`]: "-X. Discard the top 2 cards of your deck. X is the total printed cost of those discarded cards.",
    [`${skull}_Where Doom Awaits_back`]: "-2 (-5 instead if you are at an Altered location).",
    [`${cultist}_Where Doom Awaits_back`]: "Reveal another token. Cancel the effects and icons of each skill card committed to this test.",
    [`${tablet}_Where Doom Awaits_back`]: "-3. If it is Agenda 2, you automatically fail instead.",
    [`${elderThing}_Where Doom Awaits_back`]: "-X. Discard the top 3 cards of your deck. X is the total printed cost of those discarded cards.",

    [`${skull}_Lost in Time and Space_front`]: "-1 for each Extradimensional location in play (max -5).",
    [`${cultist}_Lost in Time and Space_front`]: "Reveal another token. If you fail, after this skill test, discard cards from the top of the encounter deck until a location is discarded. Put that location into play and move there.",
    [`${tablet}_Lost in Time and Space_front`]: "-3. If Yog-Sothoth is in play, it attacks you after this skill test.",
    [`${elderThing}_Lost in Time and Space_front`]: "-X. X is the shroud value of your location. If you fail and your location is Extradimensional, discard it.",
    [`${skull}_Lost in Time and Space_back`]: "-1 for each Extradimensional location in play.",
    [`${cultist}_Lost in Time and Space_back`]: "Reveal another token. After this skill test, discard cards from the top of the encounter deck until a location is discarded. Put that location into play and move there.",
    [`${tablet}_Lost in Time and Space_back`]: "-5. If Yog-Sothoth is in play, it attacks you after this skill test.",
    [`${elderThing}_Lost in Time and Space_back`]: "-X. X is twice the shroud value of your location. If you fail and your location is Extradimensional, discard it.",

    // The Path to Carcosa
    [`${skull}_Curtain Call_front`]: "-1 (-3 instead if you have 3 or more horror on you).",
    [`${cultist}_Curtain Call_front`]: "-4. If your location has at least 1 horror on it, take 1 horror (from the token pool). If your location has no horror on it, place 1 horror on it instead.",
    [`${tablet}_Curtain Call_front`]: "-4. If your location has at least 1 horror on it, take 1 horror (from the token pool). If your location has no horror on it, place 1 horror on it instead.",
    [`${elderThing}_Curtain Call_front`]: "-4. If your location has at least 1 horror on it, take 1 horror (from the token pool). If your location has no horror on it, place 1 horror on it instead.",
    [`${skull}_Curtain Call_back`]: "-X, where X is the amount of horror on you. (If you have no horror on you, X is 1.)",
    [`${cultist}_Curtain Call_back`]: "-5. If your location has at least 1 horror on it, take 1 horror (from the token pool). If your location has no horror on it, place 1 horror on it instead.",
    [`${tablet}_Curtain Call_back`]: "-5. If your location has at least 1 horror on it, take 1 horror (from the token pool). If your location has no horror on it, place 1 horror on it instead.",
    [`${elderThing}_Curtain Call_back`]: "-5. If your location has at least 1 horror on it, take 1 horror (from the token pool). If your location has no horror on it, place 1 horror on it instead.",

    [`${skull}_The Last King_front`]: "Reveal another token. If you fail, place 1 doom on a Possessed enemy in play.",
    [`${cultist}_The Last King_front`]: "-2. If you fail, place 1 of your clues on your location.",
    [`${tablet}_The Last King_front`]: "-4. If you fail, take 1 horror.",
    [`${elderThing}_The Last King_front`]: "-X. X is the shroud value of your location.",
    [`${skull}_The Last King_back`]: "Reveal another token. If you fail, place 1 doom on the Possessed enemy in play with the most remaining health.",
    [`${cultist}_The Last King_back`]: "-3. Place 1 of your clues on your location.",
    [`${tablet}_The Last King_back`]: "-4. Take 1 horror.",
    [`${elderThing}_The Last King_back`]: "-X. X is the shroud value of your location. If you fail, take 1 damage.",

    [`${skull}_Echoes of the Past_front`]: "-X. X is the highest number of doom on an enemy in play.",
    [`${cultist}_Echoes of the Past_front`]: "-2. If you fail, place 1 doom on the nearest enemy.",
    [`${tablet}_Echoes of the Past_front`]: "-2. If you fail, discard a random card from your hand.",
    [`${elderThing}_Echoes of the Past_front`]: "-2. If you fail and there is an enemy at your location, take 1 horror.",
    [`${skull}_Echoes of the Past_back`]: "-X. X is the total number of doom on enemies in play.",
    [`${cultist}_Echoes of the Past_back`]: "-4. Place 1 doom on the nearest enemy.",
    [`${tablet}_Echoes of the Past_back`]: "-4. Discard a random card from your hand.",
    [`${elderThing}_Echoes of the Past_back`]: "-4. If there is an enemy at your location, take 1 horror.",

    [`${skull}_The Unspeakable Oath_front`]: "-1. If you fail, randomly choose an enemy from among the set-aside Monster enemies and place it beneath the act deck without looking at it.",
    [`${cultist}_The Unspeakable Oath_front`]: "-X. X is the amount of horror on you.",
    [`${tablet}_The Unspeakable Oath_front`]: "-X. X is the base shroud value of your location.",
    [`${elderThing}_The Unspeakable Oath_front`]: "0. Either randomly choose an enemy from among the set-aside Monster enemies and place it beneath the act deck without looking at it, or this test automatically fails instead.",
    [`${skull}_The Unspeakable Oath_back`]: "Reveal another token. If you fail, randomly choose an enemy from among the set-aside Monster enemies and place it beneath the act deck without looking at it. (Limit once per test.)",
    [`${cultist}_The Unspeakable Oath_back`]: "-X. X is the amount of horror on you. If you fail, take 1 horror.",
    [`${tablet}_The Unspeakable Oath_back`]: "-X. X is the base shroud value of your location. If you fail, take 1 horror.",
    [`${elderThing}_The Unspeakable Oath_back`]: "0. Either randomly choose an enemy from among the set-aside Monster enemies and place it beneath the act deck without looking at it, or this test automatically fails instead.",

    [`${skull}_A Phantom of Truth_front`]: "-X. X is the amount of doom in play (max 5).",
    [`${cultist}_A Phantom of Truth_front`]: "-2. If you fail, move each unengaged Byakhee in play once toward the nearest investigator.",
    [`${tablet}_A Phantom of Truth_front`]: "-3. Cancel the effects and icons of each skill card committed to this test.",
    [`${elderThing}_A Phantom of Truth_front`]: "-2. If you fail, lose 1 resource for each point you failed by.",
    [`${skull}_A Phantom of Truth_back`]: "-X. X is the amount of doom in play.",
    [`${cultist}_A Phantom of Truth_back`]: "-2. Move each unengaged Byakhee in play once toward the nearest investigator.",
    [`${tablet}_A Phantom of Truth_back`]: "-4. Cancel the effects and icons of each skill card committed to this test.",
    [`${elderThing}_A Phantom of Truth_back`]: "-3. If you fail, lose 1 resource for each point you failed by.",

    [`${skull}_The Pallid Mask_front`]: "-X. X is the number of locations away from the starting location you are (max 5).",
    [`${cultist}_The Pallid Mask_front`]: "-2. If this token is revealed during an attack, and this skill test is successful, this attack deals 1 less damage.",
    [`${tablet}_The Pallid Mask_front`]: "-2. If there is a ready Ghoul or Geist enemy at your location, it attacks you (if there is more than one, choose one).",
    [`${elderThing}_The Pallid Mask_front`]: "-3. If you fail, search the encounter deck and discard pile for a Ghoul or Geist enemy and draw it.",
    [`${skull}_The Pallid Mask_back`]: "-X. X is the number of locations away from the starting location you are.",
    [`${cultist}_The Pallid Mask_back`]: "-3. If this token is revealed during an attack and this skill test is successful, this attack deals no damage.",
    [`${tablet}_The Pallid Mask_back`]: "-3. If there is a Ghoul or Geist enemy at your location, it readies and attacks you (if there is more than one, choose one).",
    [`${elderThing}_The Pallid Mask_back`]: "-4. If you fail, search the encounter deck and discard pile for a Ghoul or Geist enemy and draw it.",

    [`${skull}_Black Stars Rise_front`]: "-X. X is the highest amount of doom on an agenda in play.",
    [`${cultist}_Black Stars Rise_front`]: "Reveal another token. If this token is revealed during an attack or evasion attempt against an enemy with doom on it, this skill test automatically fails instead.",
    [`${tablet}_Black Stars Rise_front`]: "Reveal another token. If you fail, place 1 doom on each agenda.",
    [`${elderThing}_Black Stars Rise_front`]: "-2. If you fail, search the encounter deck and discard pile for a Byakhee enemy and draw it.",
    [`${skull}_Black Stars Rise_back`]: "-X. X is the total amount of doom on agendas in play.",
    [`${cultist}_Black Stars Rise_back`]: "Reveal another token. If there is an enemy with 1 or more doom on it at your location, this test automatically fails instead.",
    [`${tablet}_Black Stars Rise_back`]: "Reveal another token. If you do not succeed by at least 1, place 1 doom on each agenda.",
    [`${elderThing}_Black Stars Rise_back`]: "-3. If you fail, search the encounter deck and discard pile for a Byakhee enemy and draw it.",

    [`${skull}_Dim Carcosa_front`]: "-2 (-4 instead if you have no sanity remaining).",
    [`${cultist}_Dim Carcosa_front`]: "Reveal another token. If you fail, take 1 horror.",
    [`${tablet}_Dim Carcosa_front`]: "-3. If you fail and Hastur is in play, place 1 clue on your location (from the token bank).",
    [`${elderThing}_Dim Carcosa_front`]: "-3. If this token is revealed during an attack or evasion attempt against a Monster or Ancient One enemy, lose 1 action.",
    [`${skull}_Dim Carcosa_back`]: "-X. X is the amount of horror on you.",
    [`${cultist}_Dim Carcosa_back`]: "Reveal another token. If you fail, take 2 horror.",
    [`${tablet}_Dim Carcosa_back`]: "-5. If you fail and Hastur is in play, place 1 clue on your location (from the token bank).",
    [`${elderThing}_Dim Carcosa_back`]: "-5. If this token is revealed during an attack or evasion attempt against a Monster or Ancient One enemy, lose 1 action.",

    // The Forgotten Age
    [`${skull}_The Untamed Wilds_front`]: "-X. X is the number of vengeance points in the victory display.",
    [`${cultist}_The Untamed Wilds_front`]: "-X. X is the number of locations in play (max 5).",
    [`${tablet}_The Untamed Wilds_front`]: "-X. X is the number of cards in the exploration deck (max 5).",
    [`${elderThing}_The Untamed Wilds_front`]: "-2. If you are poisoned, this test automatically fails instead.",
    [`${skull}_The Untamed Wilds_back`]: "-X. X is 1 higher than the number of vengeance points in the victory display.",
    [`${cultist}_The Untamed Wilds_back`]: "-X. X is the number of locations in play.",
    [`${tablet}_The Untamed Wilds_back`]: "-X. X is the number of cards in the exploration deck (min 3).",
    [`${elderThing}_The Untamed Wilds_back`]: "-3. If you are poisoned, this test automatically fails instead. If you are not poisoned and you fail, put a set-aside Poisoned weakness into play in your threat area.",

    [`${skull}_The Doom of Eztli_front`]: "-1 (-3 instead if there is doom on your location).",
    [`${cultist}_The Doom of Eztli_front`]: "-X. X is the number of locations with doom on them.",
    [`${tablet}_The Doom of Eztli_front`]: "-X. X is the number of locations with doom on them.",
    [`${elderThing}_The Doom of Eztli_front`]: "Reveal another chaos token. If you fail, place 1 doom on your location.",
    [`${skull}_The Doom of Eztli_back`]: "-2 (-4 instead if there is doom on your location).",
    [`${cultist}_The Doom of Eztli_back`]: "-X. X is the total amount of doom on locations in play.",
    [`${tablet}_The Doom of Eztli_back`]: "-X. X is the total amount of doom on locations in play.",
    [`${elderThing}_The Doom of Eztli_back`]: "Reveal another chaos token. Place 1 doom on your location.",

    [`${skull}_Threads of Fate_front`]: "-X. X is the highest number of doom on a cultist enemy.",
    [`${cultist}_Threads of Fate_front`]: "-2. If you do not succeed by at least 1, take 1 damage.",
    [`${tablet}_Threads of Fate_front`]: "-2. If you do not succeed by at least 1, place 1 doom on the nearest cultist enemy.",
    [`${elderThing}_Threads of Fate_front`]: "-2. If you fail, lose 1 of your clues.",
    [`${skull}_Threads of Fate_back`]: "-X. X is the total number of doom in play.",
    [`${cultist}_Threads of Fate_back`]: "-2. If you do not succeed by at least 2, take 1 direct damage.",
    [`${tablet}_Threads of Fate_back`]: "-2. If you do not succeed by at least 2, place 1 doom on each cultist enemy.",
    [`${elderThing}_Threads of Fate_back`]: "-3. If you fail, lose 1 of your clues.",

    [`${skull}_The Boundary Beyond_front`]: "-1 (-3 instead if you are at an Ancient location).",
    [`${cultist}_The Boundary Beyond_front`]: "Reveal another token. If you fail, place 1 doom on a Cultist enemy.",
    [`${tablet}_The Boundary Beyond_front`]: "Reveal another token. If you fail and there is a Serpent enemy at your location, it attacks you.",
    [`${elderThing}_The Boundary Beyond_front`]: "-4. If you fail, place 1 clue (from the token pool) on the nearest Ancient location.",
    [`${skull}_The Boundary Beyond_back`]: "-2 (-4 instead if you are at an Ancient location).",
    [`${cultist}_The Boundary Beyond_back`]: "Reveal another token. If you fail, place 1 doom on each Cultist enemy.",
    [`${tablet}_The Boundary Beyond_back`]: "Reveal another token. If you fail, each Serpent enemy at your location attacks you.",
    [`${elderThing}_The Boundary Beyond_back`]: "-4. Place 1 clue (from the token pool) on the nearest Ancient location.",

    [`${skull}_Heart of the Elders_front`]: "-1 (-3 instead if you are in a Cave location).",
    [`${cultist}_Heart of the Elders_front`]: "-2. If you fail, place 1 doom on your location.",
    [`${tablet}_Heart of the Elders_front`]: "-2. If you are poisoned, this test automatically fails instead.",
    [`${elderThing}_Heart of the Elders_front`]: "-3. If you fail, take 1 horror.",
    [`${skull}_Heart of the Elders_back`]: "-2 (-4 instead if you are in a Cave location).",
    [`${cultist}_Heart of the Elders_back`]: "-3. If you fail, place 1 doom on your location.",
    [`${tablet}_Heart of the Elders_back`]: "-3. If you are poisoned, this test automatically fails instead. If you are not poisoned and you fail, put a set-aside Poisoned weakness into play in your threat area.",
    [`${elderThing}_Heart of the Elders_back`]: "-4. If you fail, take 1 horror.",

    [`${skull}_The City of Archives_front`]: "-1 (-3 instead if you have 5 or more cards in your hand).",
    [`${cultist}_The City of Archives_front`]: "-2. If you fail, place 1 of your clues on your location.",
    [`${tablet}_The City of Archives_front`]: "-3. If you fail, discard 1 random card from your hand.",
    [`${elderThing}_The City of Archives_front`]: "-2. If you fail, place 1 of your clues on your location.",
    [`${skull}_The City of Archives_back`]: "-2 (if you have 5 or more cards in your hand, you automatically fail instead).",
    [`${cultist}_The City of Archives_back`]: "-2. Place 1 of your clues on your location.",
    [`${tablet}_The City of Archives_back`]: "-3. For each point you fail by, discard 1 random card from your hand.",
    [`${elderThing}_The City of Archives_back`]: "-2. Place 1 of your clues on your location.",

    [`${skull}_The Depths of Yoth_front`]: "-X. X is the current depth level.",
    [`${cultist}_The Depths of Yoth_front`]: "Reveal another token. If you fail, each Serpent enemy at your location or a connecting location heals 2 damage.",
    [`${tablet}_The Depths of Yoth_front`]: "Reveal another token. If you fail, place 1 clue on your location (from the token pool).",
    [`${elderThing}_The Depths of Yoth_front`]: "-2. If there are 3 or more vengeance points in the victory display, you automatically fail this test, instead.",
    [`${skull}_The Depths of Yoth_back`]: "-X. X is the current depth level. If you fail, take 1 horror.",
    [`${cultist}_The Depths of Yoth_back`]: "Reveal another token. If you fail, each Serpent enemy at your location or a connecting location heals 2 damage.",
    [`${tablet}_The Depths of Yoth_back`]: "Reveal another token. If you fail, place 1 clue on your location (from the token pool).",
    [`${elderThing}_The Depths of Yoth_back`]: "-4. If there are 3 or more vengeance points in the victory display, you automatically fail this test, instead.",

    [`${skull}_Shattered Aeons_front`]: "-2 (-4 instead if the Relic of Ages is at your location).",
    [`${cultist}_Shattered Aeons_front`]: "-2. If you do not succeed by at least 1, place 1 doom on the nearest Cultist enemy.",
    [`${tablet}_Shattered Aeons_front`]: "-2. If you are poisoned, this test automatically fails instead.",
    [`${elderThing}_Shattered Aeons_front`]: "-2. If you fail, shuffle the topmost Hex treachery in the encounter discard pile into the exploration deck.",
    [`${skull}_Shattered Aeons_back`]: "-3 (-5 instead if the Relic of Ages is at your location).",
    [`${cultist}_Shattered Aeons_back`]: "-3. If you do not succeed by at least 1, place 1 doom on each Cultist enemy.",
    [`${tablet}_Shattered Aeons_back`]: "-3. If you are poisoned, this test automatically fails instead. If you are not poisoned and you fail, put a set-aside Poisoned weakness into play in your threat area.",
    [`${elderThing}_Shattered Aeons_back`]: "-3. Shuffle the topmost Hex treachery in the encounter discard pile into the exploration deck.",

    [`${skull}_Turn Back Time_front`]: "-X . X is the number of locations with doom on them.",
    [`${elderThing}_Turn Back Time_front`]: "-4. If you fail, place 1 doom on your location.",
    [`${skull}_Turn Back Time_back`]: "-X . X is the total amount of doom on locations.",
    [`${elderThing}_Turn Back Time_back`]: "-6. Place 1 doom on your location.",

    /* Template
    [`${skull}__front`]: "",
    [`${cultist}__front`]: "",
    [`${tablet}__front`]: "",
    [`${elderThing}__front`]: "",
    [`${skull}__back`]: "",
    [`${cultist}__back`]: "",
    [`${tablet}__back`]: "",
    [`${elderThing}__back`]: "",
    */
  };

  let key = `${tokenValue}_${scenario}_${normalizedDifficulty}`;

  return references[key] || "";
};

// Event Listener Functions
const drawToken = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  htmlElements.referenceText.innerHTML = '';
  tokenValues = [];
  chaosBagCopy = [...chaosBag];

  chaosBag.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  let randomIndex = Math.floor(Math.random() * tokenValues.length);
  let randomValue = tokenValues[randomIndex];
  let className = tokenNames[randomValue];
  let odds = calculateOdds(randomValue);

  // Add drawn token to history
  drawHistory.push(tokenNames[randomValue]);
  
  // Decrement the quantity of the selected token
  chaosBagCopy[randomValue]--;

  if (className === "icon-token_bless_sealed" || className === "icon-token_curse_sealed") {
    tokenValues.splice(randomIndex, 1); // Remove the value from the tokenValues array
    chaosBag[randomValue]--; // Decrement the quantity in the chaosBag array
  }

  // Disable the "Draw Token" button
  htmlElements.drawTokenButton.disabled = true;

  // Add a visual indicator
  htmlElements.drawTokenButton.innerText = "Drawing...";

  // Enable the "Reveal Another" button
  htmlElements.revealAnotherButton.disabled = false;

  // Disable the instructions
  htmlElements.instructionsElement.style.display = 'none';

  // Reset the visual indicator after a short delay
  setTimeout(() => {
    if (htmlElements.displayOddsCheckbox.checked) {
      htmlElements.contentContainer.textContent = `Odds: ${odds}`;
    } else {
      htmlElements.contentContainer.textContent = '';
    }
    htmlElements.tokenImage.className = className;
    htmlElements.drawTokenButton.disabled = false;
    htmlElements.drawTokenButton.innerText = "Draw Token";

    // Calculate the number of available tokens remaining
    let availableTokens = tokenValues.filter(value => !drawnTokens.includes(value));
    htmlElements.revealAnotherButton.innerText = `Reveal Another (${availableTokens.length - 1})`;

    let referenceText = generateReference(className, selectedScenario, selectedDifficulty);
    
    htmlElements.referenceText.textContent = referenceText;
  }, 500);
 
};


const revealAnotherToken = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  htmlElements.referenceText.innerHTML = '';

  // Calculate tokenValues
  tokenValues = [];
  chaosBagCopy.forEach((quantity, value) => {
    tokenValues.push(...Array(quantity).fill(value));
  });

  // Exclude drawn tokens from the pool
  let availableTokens = tokenValues.filter(value => !drawnTokens.includes(value));

  if (availableTokens.length === 0) {
    alert('No more tokens left!');
    return;
  }

  // Count the quantity of each available token
  let tokenCounts = {};
  availableTokens.forEach(token => {
    tokenCounts[token] = (tokenCounts[token] || 0) + 1;
  });

  // Create an array of available tokens with their quantities
  let tokensWithQuantities = Object.entries(tokenCounts);

  // Generate a random index based on the available tokens
  let randomIndex = Math.floor(Math.random() * tokensWithQuantities.length);
  let [randomValue] = tokensWithQuantities[randomIndex];
  let className = tokenNames[randomValue];
  let odds = calculateOdds(randomValue);

  // Add drawn token to history
  drawHistory.push(tokenNames[randomValue]);

  // Decrement the quantity of the selected token
  chaosBagCopy[randomValue]--;

  // Remove the token from the availableTokens if its quantity reaches zero
  if (chaosBagCopy[randomValue] === 0) {
    availableTokens = availableTokens.filter(token => token !== randomValue);
  }

  // Add the drawn token to drawnTokens
  drawnTokens.push(randomValue);

  // Disable the "Reveal Another" button
  htmlElements.revealAnotherButton.disabled = true;

  // Add a visual indicator
  htmlElements.revealAnotherButton.innerText = "Revealing...";

  // Reset the visual indicator after a short delay
  setTimeout(() => {
    let tokenImg = document.createElement('img');
    tokenImg.className = className;
    htmlElements.tokenImage.className = className;

    if (className === "icon-token_bless_sealed" || className === "icon-token_curse_sealed") {
      tokenValues.splice(randomIndex, 1); // Remove the value from the tokenValues array
      chaosBag[randomValue]--; // Decrement the quantity in the chaosBag array
    }

    if (htmlElements.displayOddsCheckbox.checked) {
      htmlElements.contentContainer.textContent = `Odds: ${odds}`;
    } else {
      htmlElements.contentContainer.textContent = '';
    }

    // Update the "Reveal Another" button text
    htmlElements.revealAnotherButton.innerText = `Reveal Another (${availableTokens.length - 1})`;

    // Enable the "Reveal Another" button
    htmlElements.revealAnotherButton.disabled = false;

    let referenceText = generateReference(className, selectedScenario, selectedDifficulty);
    htmlElements.referenceText.textContent = referenceText;
  }, 500);
};

const modifyBag = () => {
  htmlElements.overlay.classList.toggle('overlay-visible');
  htmlElements.revealAnotherButton.disabled = true;
  htmlElements.revealAnotherButton.innerText = 'Reveal Another';
  showContents();
  htmlElements.instructionsElement.style.display = 'block';
};

const addToken = () => {
  let tokenName = "icon-token_" + htmlElements.tokenInput.value + (
    htmlElements.tokenInput.value === 'cultist' || 
    htmlElements.tokenInput.value === 'tablet' || 
    htmlElements.tokenInput.value === 'skull' ||
    htmlElements.tokenInput.value === 'elder_thing' ||
    htmlElements.tokenInput.value === 'elder_sign' ||
    htmlElements.tokenInput.value === 'auto_fail' ? '_highlight' : '_sealed');
  if (tokenNames.includes(tokenName)) {
    let tokenIndex = tokenNames.indexOf(tokenName);
    if (tokenIndex !== -1) {
      chaosBag[tokenIndex] += 1;
    } else {
      alert('Invalid token name. Please select a valid token from the dropdown.');
    }
    showContents();
  } else {
    alert('Invalid token name. Please select a valid token from the dropdown.');
  }
};

const removeToken = () => {
  let tokenName = "icon-token_" + htmlElements.tokenInput.value + (
    htmlElements.tokenInput.value === 'cultist' || 
    htmlElements.tokenInput.value === 'tablet' || 
    htmlElements.tokenInput.value === 'skull' ||
    htmlElements.tokenInput.value === 'elder_thing' ||
    htmlElements.tokenInput.value === 'elder_sign' ||
    htmlElements.tokenInput.value === 'auto_fail' ? '_highlight' : '_sealed');
  if (tokenNames.includes(tokenName)) {
    let tokenIndex = tokenNames.indexOf(tokenName);
    if (tokenIndex !== -1) {
      chaosBag[tokenIndex] = Math.max(0, chaosBag[tokenIndex] - 1);
    } else {
      alert('Invalid token name. Please select a valid token from the dropdown.');
    }
    showContents();
  } else {
    alert('Invalid token name. Please select a valid token from the dropdown.');
  }
};

const closeOverlay = () => {
  htmlElements.overlay.classList.remove('overlay-visible');
};

const toggleDisplayOdds = () => {
  if (htmlElements.displayOddsCheckbox.checked) {
    showOdds();
  } else {
    hideOdds();
  }
};

const changeCampaign = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  selectedCampaign = htmlElements.campaignSelector.value;
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  showContents();
  updateSubtitle();
  updateScenarioDropdown();
};

const changeScenario = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  selectedScenario = htmlElements.scenarioSelector.value;
  showContents();
  updateSubtitle(); // Update the subtitle when the scenario changes
};

const changeDifficulty = () => {
  htmlElements.contentContainer.innerHTML = '';
  htmlElements.tokenImage.className = '';
  selectedDifficulty = htmlElements.difficultySelector.value;
  chaosBag = [...presets[selectedCampaign][selectedDifficulty]];
  showContents();
  updateSubtitle(); // Update the subtitle when the difficulty changes
};

const displayHistory = () => {
  // clear any existing history
  htmlElements.drawHistory.innerHTML = '';

  // Add the token images to the history overlay
  drawHistory.forEach(tokenName => {
    let tokenSpan = document.createElement('span');
    tokenSpan.className = tokenName;
    htmlElements.drawHistory.appendChild(tokenSpan);
  });

  // Update the total
  htmlElements.drawHistoryTotal.textContent = `${drawHistory.length}`;

  // Show the history overlay
  htmlElements.historyOverlay.classList.add('overlay-visible');
};

const closeHistoryOverlay = () => {
  htmlElements.historyOverlay.classList.remove('overlay-visible');
};


const updateProfileSubtitle = () => {
  htmlElements.subtitle.textContent = `Profile: ${htmlElements.profile.value}`;
};

// Save profile
const saveBagContents = () => {
  let selectedProfile = htmlElements.profile.value;
  if (selectedProfile.startsWith("Empty Profile")) {
    try {
      const newName = prompt("Please enter a name for your profile:");
      if (newName === null) {
        return; // User clicked cancel, close the prompt
      }
      if (newName.trim() !== "" && newName.trim() !== "Empty Profile") {
        selectedProfile = newName;
        const selectedOption = htmlElements.profile.options[htmlElements.profile.selectedIndex];
        selectedOption.text = selectedProfile;
        selectedOption.value = selectedProfile;
        updateProfileSubtitle();
      } else {
        throw new Error('Invalid profile name.'); // Throw an error to be caught later
      }
    } catch (error) {
      alert(error.message); // Display the error message
      return;
    }
  }

  const dataToSave = {
    chaosBag: chaosBag,
    campaign: selectedCampaign,
    difficulty: selectedDifficulty
  };
  const dataJSON = JSON.stringify(dataToSave);
  localStorage.setItem("profile-" + selectedProfile, dataJSON);
  alert(`Bag contents saved to profile "${selectedProfile}"!`);
};


// Load profile
const loadBagContents = () => {
  let selectedProfile = htmlElements.profile.value;
  if (selectedProfile.startsWith("Empty Profile")) {
    alert('Please select a profile to load.');
    return;
  }

  const dataJSON = localStorage.getItem("profile-" + selectedProfile);
  if (dataJSON) {
    const dataLoaded = JSON.parse(dataJSON);
    chaosBag = dataLoaded.chaosBag;
    selectedCampaign = dataLoaded.campaign;
    selectedDifficulty = dataLoaded.difficulty;
    showContents();
    updateProfileSubtitle(); // Update the subtitle
    alert(`Bag contents loaded from profile "${selectedProfile}"!`);
  } else {
    alert(`No saved bag contents found for profile "${selectedProfile}".`);
  }
};


const updateProfileName = () => {
  profileName = htmlElements.profile.value;
};

// Delete profile
const deleteProfile = () => {
  const selectedProfile = htmlElements.profile.value;
  if (selectedProfile.startsWith("Empty Profile")) {
    alert('Please select a profile to delete.');
    return;
  }

  const confirmation = confirm(`Are you sure you want to delete profile "${selectedProfile}"?`);
  if (confirmation) {
    localStorage.removeItem("profile-" + selectedProfile);
    htmlElements.profile.options[htmlElements.profile.selectedIndex] = new Option("Empty Profile", "Empty Profile");
    // Reset the chaos bag to its initial state
    resetChaosBag();
    updateSubtitle();
    showContents();
    alert(`Profile "${selectedProfile}" deleted.`);
  }
};

const loadProfileNames = () => {
  // Get all keys from local storage
  const allKeys = Object.keys(localStorage);

  // Filter out the keys that don't start with "profile-"
  const profileKeys = allKeys.filter(key => key.startsWith("profile-"));

  // Map the profile keys to profile names
  const profileNames = profileKeys.map(key => key.replace("profile-", ""));

  // Get the select element
  const select = htmlElements.profile;

  // Remove all options
  select.innerHTML = '';

  // Add an option for each profile
  profileNames.forEach(name => {
    const option = document.createElement('option');
    option.text = name;
    option.value = name;
    select.add(option);
  });

  // Add enough empty profiles to total 5 slots
  const numberOfEmptyProfilesNeeded = 5 - profileNames.length;
  for(let i = 1; i <= numberOfEmptyProfilesNeeded; i++) {
    const option = document.createElement('option');
    option.value = `Empty Profile`;
    option.text = `Empty Profile`;
    select.add(option);
  }
};

// Call loadProfileNames function during page load to populate profile select options
window.onload = loadProfileNames;

const renameProfile = () => {
  const selectedIndex = htmlElements.profile.selectedIndex;
  const oldProfileName = htmlElements.profile.value;

  // Check if the old profile name is "Empty Profile"
  if (oldProfileName === "Empty Profile") {
    alert("Please select a valid profile.");
    return;
  }

  const newProfileName = prompt("Enter the new name for the profile:");

  // Check if the profile name already exists
  if (localStorage.getItem("profile-" + newProfileName) !== null) {
    alert(`The profile name "${newProfileName}" already exists. Please enter a different name.`);
    return;
  }

  // Validate the new profile name
  if (newProfileName.trim() === "" || newProfileName.trim() === "Empty Profile") {
    alert("Invalid profile name. Please try again.");
    return;
  }

  newProfileName = newProfileName.trim(); // Remove leading/trailing whitespace

  const dataJSON = localStorage.getItem("profile-" + oldProfileName);
  if (dataJSON) {
    // Remove the old profile
    localStorage.removeItem("profile-" + oldProfileName);

    // Save the data under the new profile name
    localStorage.setItem("profile-" + newProfileName, dataJSON);

    // Update the profile name in the select options
    htmlElements.profile[selectedIndex].text = newProfileName;
    htmlElements.profile[selectedIndex].value = newProfileName;

    // update the global profileName only after a successful rename operation
    profileName = newProfileName;

    updateProfileSubtitle(); // Update the subtitle

    alert(`Profile "${oldProfileName}" has been renamed to "${newProfileName}"`);
  } else {
    alert(`No saved profile found with the name "${oldProfileName}"`);
  }
};

// Event Listeners
htmlElements.drawTokenButton.addEventListener('click', drawToken);
htmlElements.revealAnotherButton.addEventListener('click', revealAnotherToken);
htmlElements.modifyBagButton.addEventListener('click', modifyBag);
htmlElements.addTokenButton.addEventListener('click', addToken);
htmlElements.removeTokenButton.addEventListener('click', removeToken);
htmlElements.closeOverlayButton.addEventListener('click', closeOverlay);
htmlElements.displayOddsCheckbox.addEventListener('change', toggleDisplayOdds);
htmlElements.campaignSelector.addEventListener('change', changeCampaign);
htmlElements.scenarioSelector.addEventListener('change', changeScenario);
htmlElements.difficultySelector.addEventListener('change', changeDifficulty);
htmlElements.historyButton.addEventListener('click', displayHistory);
htmlElements.closeHistoryOverlayButton.addEventListener('click', closeHistoryOverlay);
htmlElements.saveButton.addEventListener('click', saveBagContents);
htmlElements.loadButton.addEventListener('click', loadBagContents);
htmlElements.profile.addEventListener('change', updateProfileName);
htmlElements.deleteButton.addEventListener('click', deleteProfile);
htmlElements.renameButton.addEventListener('click', renameProfile);
htmlElements.clearHistoryButton.addEventListener('click', clearHistory);

// Initial setup
htmlElements.revealAnotherButton.disabled = true;
hideOdds();
updateSubtitle();
updateScenarioDropdown();
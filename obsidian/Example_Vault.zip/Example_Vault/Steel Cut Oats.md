---
Ingredients:
- 425g oats (half the ShopRite container)
- 1700mL water
- 1 tbsp salt
Steps:
- 1. Combine all ingredients and bring to a boil
- 2. Lower to a simmer uncovered for 60-70 minutes or until desired consistency
- 3. (Optional) Add fruit and nuts before serving
---
**Index**:: [[Meal Prep]]
#todo

# Steel Cut Oats
TODO: confirm the 4:1 ratio of ingredients works

## Reheating
- Heat 200g of oats in the microwave for 2 minutes
- Optional: Add berries and then microwave for another 30s to warm them up

## Toppings
- 70g blueberries
- 14g pepitas
- 28g walnuts
- 1 banana
- 120g strawberries

## Notes
- Meal prepped rolled oats doesn't taste nearly as good; they taste fine freshly made tho
- Butter goes well with oats but is not necessary
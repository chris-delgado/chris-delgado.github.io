[[2022 New Orleans]]

---
# 2022 New Orleans - Attractions
## French Quarter
### Audubon Aquarium of the Americas
![[Pasted image 20220831195421.png]]
- https://audubonnatureinstitute.org/aquarium
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d104456-Reviews-Audubon_Aquarium_of_the_Americas-New_Orleans_Louisiana.html)
- **Hours:** 10AM-5PM every day (closed Tuesdays)
- **Fodor's New Orleans:** This giant aquatic showplace perched on the Mississippi riverfront has four major exhibit areas: the Amazon Rain Forest, the Mississippi River, the Gulf of Mexico, and the Great Maya Reef gallery, all of which have fish and animals native to their respective environments. One special treat is Parakeet Pointe, where you can spend time amid hundreds of parakeets and feed them by hand.

### Bourbon Street
![[Pasted image 20220828172324.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d143295-Reviews-Bourbon_Street-New_Orleans_Louisiana.html)
- **Fodor's New Orleans:** The spirit of unbridled revelry here is as alive as ever. The noise, raucous crowds, and bawdy sights are not family fare, however.

### French Market
![[Pasted image 20220830180213.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d181631-Reviews-French_Market-New_Orleans_Louisiana.html)
- **Fodor's New Orleans:** The sounds, colors, and smells here are alluring: ships' horns on the river, street performers, pralines, muffulettas, sugarcane, and Creole tomatoes. Originally a Native American trading post and later a bustling open-air market under the French and Spanish.

### Jackson Square
![[Pasted image 20220828172119.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d104486-Reviews-Jackson_Square-New_Orleans_Louisiana.html)
- **Hours:** 8AM-6PM every day
- **Fodor's New Orleans:** Surrounded by historic buildings and atmospheric street life, this beautifully landscaped park is the heart of the French Quarter

### Pharmacy Museum
![[Pasted image 20220831200249.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d133387-Reviews-New_Orleans_Pharmacy_Museum-New_Orleans_Louisiana.html)
- **Hours:** 10AM-5PM every day (closed Sundays)
- **Fodor's New Orleans:** To tour this musty shop is to step back into 19th-century medicine-the window display alone, with its enormous leech jar and other antiquated paraphernalia, is fascinating.

### St. Louis Cathedral
![[Pasted image 20220828172355.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d105727-Reviews-St_Louis_Cathedral-New_Orleans_Louisiana.html)
- **Hours:** 8:30AM-4PM most days
- **Fodor's New Orleans:** The oldest active Catholic cathedral in the United States, this beautiful church and basilica at the heart of the Old City is named for the 13th-century French king who led two crusades.

### The Cabildo
![[Pasted image 20220830180154.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d109148-Reviews-Cabildo-New_Orleans_Louisiana.html)
- **Hours:** 9AM-3:30PM every day
- **Fodor's New Orleans:** Dating from 1799, this Spanish colonial building is named for the Spanish council - or cabildo - that met here. The transfer of Louisiana to the United States was finalized in 1803 on the second floor overlooking the square. Houses a bronze death mask of Napoleon.

### The Presbytere
![[Pasted image 20220828172146.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d144072-Reviews-The_Presbytere-New_Orleans_Louisiana.html)
- **Hours:** 9AM-4PM every day
- **Fodor's New Orleans:** One of the twin Spanish colonial building flanking the St. Louis Cathedral, this one, on the right, was built on the site of the priests' residence, or presbytere. Now a museum.

### Woldenberg Riverfront Park
![[Pasted image 20220830180925.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d109152-Reviews-Woldenberg_Riverfront_Park-New_Orleans_Louisiana.html)
- **Hours:** 6AM-10PM every day
- **Fodor's New Orleans:** Prime territory for watching everyday life along the Mississippi.

## Faubourg Marigny
- Pronounced FOE-berg MA-ruh-nee

### Frenchmen Street
![[Pasted image 20220828172234.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d620600-Reviews-Frenchmen_Street-New_Orleans_Louisiana.html)
- **Fodor's New Orleans:** The three-block stretch closest to the French Quarter is where it's at - complete with cafes, bars, and music clubs. The true magic happens come nightfall, when live music spills from the doorways of clubs and crowds gather for street performers, but it's still a great daytime destination, too.

## CBD & Warehouse District
### Contemporary Arts Center
![[Pasted image 20220831202131.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d144088-Reviews-Contemporary_Arts_Center-New_Orleans_Louisiana.html)
- **Hours:** 11AM-5PM every day (closed Tuesdays)
- **Fodor's New Orleans:** Take in cutting-edge exhibits, featuring both local artists and the work of national and international talent, at this cornerstone of the vibrant Warehouse District.

### Harrah's New Orleans
![[Pasted image 20220831195106.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d106446-Reviews-Harrah_s_Casino_New_Orleans-New_Orleans_Louisiana.html)
- **Fodor's New Orleans:** Some 115,000 square feet of gaming space is divided into five areas, each with a New Orleans theme: Jazz Court, Court of Good Fortune, Smugglers Court, Mardi Gras Court, and Court of the Mansion.

### Lafayette Square
![[Pasted image 20220831195200.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d4052603-Reviews-Lafayette_Square-New_Orleans_Louisiana.html)
- **Hours:** 6AM-10:30PM every day
- **Fodor's New Orleans:** This 2.5 acre park occupies one city block in between the Federal Complex and Gallier Hall.

### Mardi Gras World
![[Pasted image 20220831200528.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d104455-Reviews-Blaine_Kern_s_Mardi_Gras_World-New_Orleans_Louisiana.html)
- **Hours:** 9AM-5:30PM every day
- **Fodor's New Orleans:** If you're not in town for the real thing, here's a fun (and family-friendly) backstage look at the history and artistry of Carnival.

### Ogden Museum of Southern Art
![[Pasted image 20220831200607.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d108039-Reviews-Ogden_Museum_of_Southern_Art-New_Orleans_Louisiana.html)
- **Hours:** 10AM-5PM every day
- **Fodor's New Orleans:** Art by Southern artists, made in the South, about the South, and exploring Southern themes fills this elegant five-story building.

### Superdome
![[Pasted image 20220831195016.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d108481-Reviews-Mercedes_Benz_Superdome-New_Orleans_Louisiana.html)
- **Fodor's New Orleans:** Home to the NFL's New Orleans Saints. Site of many Super Bowls, several NCAA Final Four basketball tournaments, the BCS championship game and many concerts.

### The National WWII Museum
![[Pasted image 20220831194951.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d106440-Reviews-The_National_WWII_Museum-New_Orleans_Louisiana.html)
- **Hours:** 9AM-5PM every day
- **Fodor's New Orleans:** A moving and well-executed examination of World War II events and its aftermath.

## The Garden District
### Lafayette Cemetery No. 1
![[Pasted image 20220831194925.png]]
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d108492-Reviews-Lafayette_Cemetery_No_1-New_Orleans_Louisiana.html)
- **Fodor's New Orleans:** This magnolia-shaded cemetery opened in 1833. Many who fought or played a role in the Civil War have plots here, indicated by plaques and headstones that detail the site of their death. Movies such as Interview with the Vampire and Double Jeopardy have used this walled cemetery for its eerie beauty.

## City Park
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d108045-Reviews-New_Orleans_City_Park-New_Orleans_Louisiana.html)
- **Hours:** 8AM - 5PM every day
- **Fodor's New Orleans:** Founded in 1854, this 1,300-acre expanse of moss-draped oaks and 11 miles of gentle lagoons is just 2 miles from the French Quarter, but feels like it could be a world apart.

### Big Lake
![[Pasted image 20220827181439.png]]
[Bike/Boat Rentals](https://wheelfunrentals.com/la/new-orleans/city-park-new-orleans/rentals/)

### Botanical Gardens
![[Pasted image 20220827181741.png]]
- https://neworleanscitypark.com/index.php/botanical-garden
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d561882-Reviews-New_Orleans_Botanical_Gardens-New_Orleans_Louisiana.html)
- **Fodor's New Orleans:** One of the few remaining examples of public garden design from the art-deco period. The garden's collections contain more than 2,000 varieties of plants from all over the world.

### Couturie Forest
![[Pasted image 20220827181920.png]]
- https://neworleanscitypark.com/index.php/in-the-park/couturie-forest

### New Orleans Museum of Art
![[Pasted image 20220827181704.png]]
- https://noma.org
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d106444-Reviews-New_Orleans_Museum_of_Art-New_Orleans_Louisiana.html)
- **Hours:** 10AM - 5PM every day
- **Fodor's New Orleans:** Gracing the main entrance to City Park since 1911, this traditional fine-arts museum draws from classic Greek architecture, with several modern wings that bring additional light and space to the grand old building.

### Old Grove
![[Pasted image 20220827182004.png]]
- https://neworleanscitypark.com/blog/800-years-old-and-stlll-lookin-good
- **Fodor's New Orleans:** With the largest collection of live oaks in the world, including old grove trees that are more than 600 years old, City Park offers a certain natural majesty that's difficult to find in most other urban areas.

### The Peristyle
![[Pasted image 20220827182040.png]]
- https://neworleanscitypark.com/rentals-and-catering/venues/peristyle

### The Sydney and Walda Besthoff Sculpture Garden
![[Pasted image 20220827181629.png]]
- https://noma.org/besthoff-sculpture-garden/
- [Tripadvisor](https://www.tripadvisor.com/Attraction_Review-g60864-d3723157-Reviews-The_Sydney_and_Walda_Besthoff_Sculpture_Garden_at_NOMA-New_Orleans_Louisiana.html)
- **Fodor's New Orleans:** A fascinating combination of famed traditional sculpture and contemporary works.
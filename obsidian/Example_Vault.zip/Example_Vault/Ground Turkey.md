---
Ingredients: 
- 3 shoprite containers of 93% lean
- 2 tbsp salt
- 2 tbsp pepper
Steps:
- 1. Combine ingredients in skillet over medium-high heat
- 2. Cook until turkey is no longer pink
---
**Index**:: [[Meal Prep]]

# Ground Turkey
## Ingredients
- 3 shop rite containers of 93% lean
- 2 tbsp salt
- 2 tbsp pepper

## Steps

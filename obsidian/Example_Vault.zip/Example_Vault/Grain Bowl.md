---
Ingredients:
- 125g ground turkey / chicken breast
- 125g black / pink beans
- 125g bulgur / farro
- 125g peas
- 30mL crystal hot sauce
Steps:
- 1. Combine dry ingredients
- 2. If needed, heat up in microwave 2 minutes
- 3. Add hot sauce
---
**Index**:: [[Meal Prep]]

# Grain Bowl

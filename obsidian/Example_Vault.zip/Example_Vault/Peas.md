---
Ingredients:
- ~500g frozen peas (half a ShopRite bag)
- .5 cup water
Steps:
- 1. Combine ingredients and bring to a boil
- 2. Lower to a simmer and cover for 6 minutes
---
**Index**:: [[Meal Prep]]

# Peas
